# StreamX — Hosting Kwa Simu Pekee (Bila PC)

Mwongozo huu unakuonyesha jinsi ya ku-host StreamX nzima ukitumia simu
pekee. Hakuna hatua yoyote inayohitaji kompyuta.

**Zana tatu tu unazohitaji, zote za bure:**
1. **GitHub** — mahali code inapokaa
2. **GitHub Codespaces** — "kompyuta" yako ya kuandika/kupandisha code, inafunguka ndani ya kivinjari cha simu
3. **GitHub Actions** — hu-build APK ya Flutter kwa niaba yako (huhitaji Flutter kwenye simu)

---

## Hatua 0: Andaa akaunti

- Tengeneza akaunti ya bure kwenye **github.com** (kama huna)
- Tengeneza akaunti kwenye **render.com** (backend) na **vercel.com** (admin + landing) — zote zinaruhusu "Sign up with GitHub" kwa mbofyo mmoja

---

## Hatua 1: Tengeneza Repos 4 kwenye GitHub

Kwenye kivinjari cha simu, github.com → **New repository** — tengeneza hizi nne, zote **Private** ni sawa:

- `streamx-backend`
- `streamx-admin`
- `streamx-app`
- `streamx-landing`

Usiweke chochote ndani yao bado (empty repo, bila README).

---

## Hatua 2: Pandisha Code Kila Repo Kupitia Codespaces

Kwa kila repo (rudia mara 4):

1. Fungua repo husika kwenye github.com
2. Bonyeza kitufe cha kijani **"Code"** → tab ya **"Codespaces"** → **"Create codespace on main"**
3. Itafungua VS Code kamili ndani ya kivinjari chako (subiri sekunde chache)
4. Kwenye Explorer (upande wa kushoto), bonyeza "..." → **Upload...** → chagua zip niliyokupa (`streamx-complete-project.zip`) kutoka kwenye storage ya simu yako
5. Fungua **Terminal** (menu ya juu → Terminal → New Terminal) na andika:

```bash
unzip streamx-complete-project.zip
```

6. Kisha hamisha files za sehemu husika kwenda root ya repo (mfano kwa `streamx-backend`):

```bash
cp -r streamx-project/streamx-backend/. .
rm -rf streamx-project streamx-complete-project.zip
```

   (Kwa repo ya `streamx-app`, tumia `streamx-project/streamx-app/.` badala yake — na kadhalika kwa `streamx-admin` na `streamx-landing`.)

7. Hatimaye:

```bash
git add .
git commit -m "Initial StreamX upload"
git push
```

Kila kitu kimeenda GitHub — Codespace inaweza kufungwa (haihitajiki tena kwa repo hiyo).

> **Kidokezo:** GitHub inatoa muda fulani wa Codespaces bila malipo kila mwezi (angalia github.com/settings/billing kwa kiwango cha sasa). Kwa mradi huu mdogo, muda huo unatosha kabisa.

---

## Hatua 3: Deploy Backend (Render)

1. render.com → **New** → **Web Service** → unganisha akaunti ya GitHub → chagua repo `streamx-backend`
2. Build command: `npm install` — Start command: `npm start`
3. Kwenye tab ya **Environment**, ongeza variables zote kutoka `.env.example` (MONGO_URI, JWT_SECRET, ADMIN_JWT_SECRET, PRIMARY_CONTENT_API, n.k.) — kwa MONGO_URI, tengeneza cluster ya bure kwenye **mongodb.com/atlas** (inafanya kazi kikamilifu kwenye kivinjari cha simu)
4. **Deploy**. Baada ya dakika chache utapata URL kama `https://streamx-backend-xxxx.onrender.com`
5. Tengeneza admin wa kwanza: Render → Shell tab (kwenye dashboard ya service yako, kivinjarini) → andika:
   ```bash
   node scripts/createSuperAdmin.js "Jina Lako" wewe@example.com "password-imara"
   ```

---

## Hatua 4: Deploy Admin Dashboard (Vercel)

1. vercel.com → **Add New** → **Project** → chagua repo `streamx-admin`
2. Framework preset: **Vite** (Vercel kawaida inaigundua yenyewe)
3. Environment variable: `VITE_API_URL` = `https://streamx-backend-xxxx.onrender.com/api`
4. **Deploy**. Utapata URL kama `https://streamx-admin-xxxx.vercel.app`
5. Fungua, ingia na akaunti ya superadmin uliyotengeneza Hatua 3, anza kuongeza movies/music/n.k.

---

## Hatua 5: Build APK (GitHub Actions — hakuna Flutter kwenye simu!)

1. Kwenye repo ya `streamx-app` kwenye github.com: **Settings** → **Secrets and variables** → **Actions** → **New repository secret**
   - Name: `API_BASE_URL`
   - Value: `https://streamx-backend-xxxx.onrender.com/api`
2. Nenda tab ya **Actions** → utaona workflow "Build StreamX APK" ikiwa tayari imeanza kukimbia (ilianzishwa na push ya Hatua 2), au bonyeza **Run workflow** kuianzisha wewe mwenyewe
3. Subiri dakika 5–10 (unaweza kufunga kivinjari na kurudi baadaye)
4. Ikimaliza (alama ya kijani ✓), bonyeza kwenye run hiyo → chini kabisa sehemu ya **Artifacts** → pakua `streamx-release-apk`
5. Hiyo ni faili la `.zip` lenye APK ndani — fungua kwenye simu (File Manager yoyote inaweza ku-extract zip), kisha sakinisha APK moja kwa moja kwenye simu yako ya Android kujaribu

Kila ukitaka toleo jipya baadaye, badilisha code kwenye Codespace, `git push`, na Actions itajenga APK mpya kiotomatiki.

---

## Hatua 6: Deploy Landing Page (Vercel)

1. Kwanza, kwenye Codespace ya `streamx-landing`, hariri `config.js`:
   ```js
   API_BASE_URL: "https://streamx-backend-xxxx.onrender.com/api",
   TELEGRAM_FALLBACK_URL: "https://t.me/channel_yako",
   ```
   Kisha `git add . && git commit -m "Set config" && git push`
2. vercel.com → **Add New** → **Project** → chagua repo `streamx-landing`
3. Framework preset: **Other** (hakuna build inayohitajika)
4. **Deploy**. Hii ndiyo link yako kuu ya kutuma kwenye WhatsApp/Telegram/Instagram

---

## Muhtasari wa Muunganiko

```
streamx-backend (Render)  ──┐
                             ├──▶  streamx-admin (Vercel) — unaingia hapa kusimamia content
                             ├──▶  streamx-app (APK kutoka GitHub Actions)
                             └──▶  streamx-landing (Vercel) — link unayosambaza
```

Ukishafika hapa, mradi mzima unafanya kazi ukiwa umeuendesha kutoka simu
moja pekee, bila kompyuta hata siku moja.
