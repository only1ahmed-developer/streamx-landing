# StreamX — Full Project

A complete MovieBox/Netflix-style streaming super-app: Movies, TV Shows,
Anime, Music, Sports, News, Live Events, Education, and Shorts — built as
four coordinated pieces that all talk to one backend.

All 10 planned Grades are complete. This is the final, ready-to-host state
of the project.

## The four pieces

```
streamx-project/
├── streamx-backend/    Node.js/Express API + MongoDB — the single source of truth
├── streamx-admin/      React Admin Dashboard — separate login, manages everything
├── streamx-app/        Flutter app — Android / iOS / Web from one codebase
└── streamx-landing/    Static landing page — device-aware download page
```

Each has its own README with full setup/deploy instructions. This file is
the map that ties them together and gives you the *order* to deploy them
in, since each one needs a URL from the one before it.

**Kwa simu pekee (bila PC):** soma `PHONE-DEPLOYMENT-GUIDE.md` — mwongozo
kamili wa hatua kwa hatua unaotumia GitHub Codespaces + GitHub Actions
kufanya kila kitu, ikiwemo ku-build APK, bila kuhitaji kompyuta wala
Flutter kwenye simu yako.

## Architecture

```
                         ┌─────────────────────┐
                         │   Admin Dashboard    │  (React, own login)
                         │   streamx-admin      │
                         └──────────┬───────────┘
                                    │ REST (admin JWT)
                                    ▼
┌──────────────┐         ┌─────────────────────┐         ┌──────────────────┐
│  Flutter App │ ───────▶│   Backend (BFF)      │────────▶│  Dave Tech API    │
│  streamx-app │  REST   │   streamx-backend     │  proxy  │  (external)       │
└──────────────┘ (user   │   Node.js + MongoDB   │         └──────────────────┘
                   JWT)   └──────────┬───────────┘
                                    │
                         ┌──────────▼───────────┐
                         │   Landing Page        │  (static, reads /app-config)
                         │   streamx-landing     │
                         └───────────────────────┘
```

The Flutter app **never** talks to the Dave Tech API directly — everything
goes through the backend, so you can change content sources, add caching,
or add ads/business logic without ever touching the app or resubmitting
it anywhere.

## Deployment order

Deploy in this order — each step needs the URL from the step before.

### 1. Backend (Render)

See `streamx-backend/README.md`. You'll end up with something like
`https://streamx-api.onrender.com`. Run `scripts/createSuperAdmin.js`
once you're live.

### 2. Admin Dashboard (Vercel)

See `streamx-admin/README.md`. Set `VITE_API_URL` to
`https://streamx-api.onrender.com/api`. Log in with the superadmin you
just created, and add your first few titles.

### 3. Flutter App

See `streamx-app/README.md` — **read the "before you do anything else"
section first**, it needs `flutter create .` to generate native platform
folders that couldn't be created in this environment. Set `API_BASE_URL`
in `.env` to the same backend URL, then build your APK (and optionally
the web build).

### 4. Landing Page (Vercel or Netlify)

See `streamx-landing/README.md`. Set `API_BASE_URL` in `config.js` to the
backend, and `TELEGRAM_FALLBACK_URL` / `WEB_APP_URL` as you have them.
This is the one link you share everywhere.

## Tech stack

| Layer | Technology |
|---|---|
| Backend | Node.js, Express, MongoDB (Mongoose), Redis (optional cache) |
| Admin Dashboard | React, Vite, Tailwind CSS, Recharts |
| Mobile/Web App | Flutter — Provider, video_player + Chewie, just_audio, google_mobile_ads |
| Landing Page | Plain HTML/CSS/JS, no build step |
| Hosting | Render (backend), Vercel (admin + landing), Flutter build → Telegram/Play Store (app) |

## Environment variables at a glance

| Variable | Lives in | Purpose |
|---|---|---|
| `MONGO_URI` | backend | Database connection |
| `JWT_SECRET` / `ADMIN_JWT_SECRET` | backend | Two **different** signing secrets |
| `REDIS_URL` | backend | Optional caching |
| `PRIMARY_CONTENT_API` | backend | Your Dave Tech API base URL |
| `VITE_API_URL` | admin dashboard | Points at the backend |
| `API_BASE_URL` | Flutter app (`.env`) | Points at the backend |
| `API_BASE_URL` | landing page (`config.js`) | Points at the backend |
| AdMob App ID | Flutter native files | See `streamx-app/README.md` |

Every real secret lives in an env var or the hosting platform's dashboard
— never hardcoded in source, exactly as planned from the start.

## Feature summary by Grade

| Grade | What it delivered |
|---|---|
| 1 | Backend foundation — server, MongoDB models, JWT setup |
| 2 | Auth API, unified Content API, subscription access-control logic |
| 3 | Admin Dashboard — CMS, Ads/Config manager, Users, Analytics |
| 4 | Flutter app shell — theme, Bottom Nav + Sidebar, startup maintenance check |
| 5 | Home + all category pages wired to real content, full Details screen |
| 6 | Video player (quality switching, custom subtitles), Live player, Music mini-player |
| 7 | Live Events tabs, Shorts swipe feed, real offline downloads |
| 8 | Register/Login, synced watchlist, profiles, watch-progress |
| 9 | AdMob banners/interstitials, and the Rewarded-Ad-unlocks-HD flow |
| 10 | Smart landing page + this deployment guide |

## Honest limitations / good next steps

- **Native platform folders**: the Flutter project ships as pure Dart
  source; run `flutter create .` before building (see `streamx-app/README.md`).
- **Payments**: subscription upgrades are handled manually today (contact
  via Telegram → admin flips the tier in the dashboard), matching the
  M-Pesa/manual-confirmation workflow discussed during planning. A real
  payment gateway (M-Pesa API, Stripe, etc.) is a natural next addition,
  wired into `PATCH /api/admin/users/:id/subscription`.
- **Episodes/Seasons UI**: the backend schema supports TV seasons and
  episodes; the app currently plays the top-level `streamLinks` for any
  title. A season/episode picker on the Details screen is a good next
  addition for multi-episode shows.
- **Real screenshots**: the landing page uses illustrative CSS mockups
  until you've built and run the app yourself — see
  `streamx-landing/README.md` for how to swap them in.
