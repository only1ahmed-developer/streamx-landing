import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';
import 'package:just_audio_background/just_audio_background.dart';
import '../models/content_model.dart';

/// Wraps a single [AudioPlayer] instance for music playback across the
/// whole app. Provided once at the app root (see main.dart) so the
/// MiniPlayer, the full Now-Playing screen, and the Music tab all share
/// the same playback state.
class AudioPlayerService extends ChangeNotifier {
  final AudioPlayer _player = AudioPlayer();
  ContentModel? currentTrack;

  Stream<Duration> get positionStream => _player.positionStream;
  Stream<Duration?> get durationStream => _player.durationStream;
  Stream<PlayerState> get playerStateStream => _player.playerStateStream;
  bool get isPlaying => _player.playing;

  Future<void> playTrack(ContentModel track, String url) async {
    try {
      currentTrack = track;
      notifyListeners();

      await _player.setAudioSource(
        AudioSource.uri(
          Uri.parse(url),
          tag: MediaItem(
            id: track.id,
            title: track.title,
            artist: track.cast.isNotEmpty
                ? track.cast.first
                : (track.director.isNotEmpty ? track.director : 'StreamX'),
            artUri: track.displayPoster.isNotEmpty ? Uri.tryParse(track.displayPoster) : null,
          ),
        ),
      );
      await _player.play();
    } catch (e) {
      debugPrint('[AudioPlayerService] playback error: $e');
    }
  }

  Future<void> togglePlayPause() async {
    if (_player.playing) {
      await _player.pause();
    } else {
      await _player.play();
    }
    notifyListeners();
  }

  Future<void> seek(Duration position) => _player.seek(position);

  Future<void> stop() async {
    await _player.stop();
    currentTrack = null;
    notifyListeners();
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
