import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../core/config/api_config.dart';
import '../models/user_model.dart';

/// The single source of truth for "who is signed in", shared across the
/// whole app via Provider. The JWT lives in secure storage (not plain
/// SharedPreferences) since it's a credential, not just app data.
class AuthService extends ChangeNotifier {
  static const _tokenKey = 'streamx_auth_token';
  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  String? _token;
  UserModel? currentUser;
  bool isLoading = false;
  String? error;

  bool get isLoggedIn => _token != null && currentUser != null;
  String? get token => _token;

  Map<String, String> get _authHeaders => {
        'Content-Type': 'application/json',
        if (_token != null) 'Authorization': 'Bearer $_token',
      };

  /// Called once at startup (from the splash screen) to restore a
  /// previous session without making the person log in every time.
  Future<void> loadSession() async {
    _token = await _storage.read(key: _tokenKey);
    if (_token != null) {
      await fetchProfile();
    }
  }

  Future<bool> register({required String name, required String email, required String password}) async {
    isLoading = true;
    error = null;
    notifyListeners();
    try {
      final response = await http
          .post(
            Uri.parse('${ApiConfig.baseUrl}/auth/register'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({'name': name, 'email': email, 'password': password}),
          )
          .timeout(const Duration(seconds: 12));

      final body = json.decode(response.body) as Map<String, dynamic>;
      if (response.statusCode != 201 || body['success'] != true) {
        throw Exception(body['message'] as String? ?? 'Registration failed.');
      }

      _token = body['token'] as String;
      await _storage.write(key: _tokenKey, value: _token);
      await fetchProfile();
      isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      isLoading = false;
      error = e.toString().replaceFirst('Exception: ', '');
      notifyListeners();
      return false;
    }
  }

  Future<bool> login({required String email, required String password}) async {
    isLoading = true;
    error = null;
    notifyListeners();
    try {
      final response = await http
          .post(
            Uri.parse('${ApiConfig.baseUrl}/auth/login'),
            headers: {'Content-Type': 'application/json'},
            body: json.encode({'email': email, 'password': password}),
          )
          .timeout(const Duration(seconds: 12));

      final body = json.decode(response.body) as Map<String, dynamic>;
      if (response.statusCode != 200 || body['success'] != true) {
        throw Exception(body['message'] as String? ?? 'Login failed.');
      }

      _token = body['token'] as String;
      await _storage.write(key: _tokenKey, value: _token);
      await fetchProfile();
      isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      isLoading = false;
      error = e.toString().replaceFirst('Exception: ', '');
      notifyListeners();
      return false;
    }
  }

  Future<void> fetchProfile() async {
    if (_token == null) return;
    try {
      final response = await http
          .get(Uri.parse('${ApiConfig.baseUrl}/auth/me'), headers: _authHeaders)
          .timeout(const Duration(seconds: 12));

      if (response.statusCode == 401) {
        await logout();
        return;
      }

      final body = json.decode(response.body) as Map<String, dynamic>;
      if (body['success'] == true) {
        currentUser = UserModel.fromJson(body['user'] as Map<String, dynamic>);
        notifyListeners();
      }
    } catch (e) {
      debugPrint('[AuthService] fetchProfile error: $e');
    }
  }

  Future<void> logout() async {
    _token = null;
    currentUser = null;
    await _storage.delete(key: _tokenKey);
    notifyListeners();
  }

  bool isInWatchlist(String contentId) {
    return currentUser?.watchlist.any((c) => c.id == contentId) ?? false;
  }

  Future<bool> addToWatchlist(String contentId) async {
    if (_token == null) return false;
    try {
      await http
          .post(Uri.parse('${ApiConfig.baseUrl}/auth/watchlist/$contentId'), headers: _authHeaders)
          .timeout(const Duration(seconds: 12));
      await fetchProfile();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> removeFromWatchlist(String contentId) async {
    if (_token == null) return false;
    try {
      await http
          .delete(Uri.parse('${ApiConfig.baseUrl}/auth/watchlist/$contentId'), headers: _authHeaders)
          .timeout(const Duration(seconds: 12));
      await fetchProfile();
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<bool> addProfile({required String name, required bool isKidsProfile}) async {
    if (_token == null) return false;
    try {
      final response = await http
          .post(
            Uri.parse('${ApiConfig.baseUrl}/auth/profiles'),
            headers: _authHeaders,
            body: json.encode({'name': name, 'isKidsProfile': isKidsProfile}),
          )
          .timeout(const Duration(seconds: 12));

      final body = json.decode(response.body) as Map<String, dynamic>;
      if (response.statusCode != 201 || body['success'] != true) return false;
      await fetchProfile();
      return true;
    } catch (e) {
      return false;
    }
  }

  /// Saves "Continue Watching" progress. Called periodically by the
  /// video player (Grade 6) while a signed-in user is watching.
  Future<void> saveWatchProgress(String contentId, int progressSeconds, {int? season, int? episode}) async {
    if (_token == null) return;
    try {
      await http
          .put(
            Uri.parse('${ApiConfig.baseUrl}/auth/watch-history'),
            headers: _authHeaders,
            body: json.encode({
              'contentId': contentId,
              'progressSeconds': progressSeconds,
              if (season != null) 'season': season,
              if (episode != null) 'episode': episode,
            }),
          )
          .timeout(const Duration(seconds: 12));
    } catch (e) {
      debugPrint('[AuthService] saveWatchProgress error: $e');
    }
  }
}
