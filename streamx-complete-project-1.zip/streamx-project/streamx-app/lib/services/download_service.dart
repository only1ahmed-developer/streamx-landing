import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/content_model.dart';
import '../models/download_item_model.dart';

/// Manages offline downloads: the actual file transfer (with progress),
/// where files live on-device, and a small persisted index so the
/// Downloads tab still shows everything after the app restarts.
///
/// The URL passed into [startDownload] must already come from the
/// backend's GET /content/:id/download, which enforces the Free /
/// Streamer / Super Streamer download rules server-side — this service
/// only ever moves bytes it's already been cleared to move.
class DownloadService extends ChangeNotifier {
  static const _prefsKey = 'streamx_downloads_v1';

  final Dio _dio = Dio();
  final Map<String, DownloadItem> _downloads = {};
  final Map<String, CancelToken> _cancelTokens = {};

  List<DownloadItem> get downloads {
    final list = _downloads.values.toList();
    list.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    return list;
  }

  DownloadItem? statusFor(String contentId) => _downloads[contentId];
  bool isDownloading(String contentId) => _downloads[contentId]?.status == DownloadStatus.downloading;

  Future<void> loadSaved() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_prefsKey);
    if (raw == null) return;

    try {
      final list = (json.decode(raw) as List)
          .map((e) => DownloadItem.fromJson(e as Map<String, dynamic>))
          .toList();
      for (final item in list) {
        // Drop entries whose files vanished (e.g. app storage was cleared).
        if (await File(item.localPath).exists()) {
          _downloads[item.contentId] = item;
        }
      }
      notifyListeners();
    } catch (e) {
      debugPrint('[DownloadService] failed to load saved downloads: $e');
    }
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    final list = _downloads.values.map((e) => e.toJson()).toList();
    await prefs.setString(_prefsKey, json.encode(list));
  }

  Future<void> startDownload(ContentModel content, String sourceUrl, String quality) async {
    final dir = await getApplicationDocumentsDirectory();
    final downloadsDir = Directory('${dir.path}/streamx_downloads');
    if (!await downloadsDir.exists()) {
      await downloadsDir.create(recursive: true);
    }

    final extension = sourceUrl.contains('.m3u8') ? 'm3u8' : 'mp4';
    final localPath = '${downloadsDir.path}/${content.id}_$quality.$extension';

    final cancelToken = CancelToken();
    _cancelTokens[content.id] = cancelToken;

    _downloads[content.id] = DownloadItem(
      contentId: content.id,
      title: content.title,
      poster: content.displayPoster,
      quality: quality,
      localPath: localPath,
      totalBytes: 0,
      downloadedBytes: 0,
      status: DownloadStatus.downloading,
    );
    notifyListeners();

    try {
      await _dio.download(
        sourceUrl,
        localPath,
        cancelToken: cancelToken,
        onReceiveProgress: (received, total) {
          final existing = _downloads[content.id];
          if (existing == null) return;
          _downloads[content.id] = existing.copyWith(
            downloadedBytes: received,
            totalBytes: total > 0 ? total : existing.totalBytes,
          );
          notifyListeners();
        },
      );

      final finished = _downloads[content.id];
      if (finished != null) {
        _downloads[content.id] = finished.copyWith(status: DownloadStatus.completed);
      }
      await _persist();
    } on DioException catch (e) {
      if (CancelToken.isCancel(e)) {
        _downloads.remove(content.id);
      } else {
        final existing = _downloads[content.id];
        if (existing != null) _downloads[content.id] = existing.copyWith(status: DownloadStatus.failed);
      }
      await _persist();
    } catch (e) {
      final existing = _downloads[content.id];
      if (existing != null) _downloads[content.id] = existing.copyWith(status: DownloadStatus.failed);
      await _persist();
    } finally {
      _cancelTokens.remove(content.id);
      notifyListeners();
    }
  }

  void cancelDownload(String contentId) {
    _cancelTokens[contentId]?.cancel('Cancelled by user');
  }

  Future<void> deleteDownload(String contentId) async {
    final item = _downloads[contentId];
    if (item == null) return;

    final file = File(item.localPath);
    if (await file.exists()) await file.delete();

    _downloads.remove(contentId);
    notifyListeners();
    await _persist();
  }
}
