import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../core/config/api_config.dart';
import '../models/app_config_model.dart';

/// Fetches the backend's "remote control" document. Used at startup
/// (splash screen) to decide whether to show Maintenance Mode, and by
/// the Updates tab to show version / Telegram info.
class AppConfigService extends ChangeNotifier {
  AppConfigModel? config;
  bool isLoading = false;
  String? error;

  Future<void> fetchConfig() async {
    isLoading = true;
    error = null;
    notifyListeners();

    try {
      final uri = Uri.parse('${ApiConfig.baseUrl}/app-config');
      final response = await http.get(uri).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final body = json.decode(response.body) as Map<String, dynamic>;
        config = AppConfigModel.fromJson(body['data'] as Map<String, dynamic>);
      } else {
        error = 'StreamX is unreachable right now (${response.statusCode}).';
      }
    } catch (_) {
      error = 'No internet connection. Please check your network.';
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }
}
