import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../models/app_config_model.dart';

/// Google's official test ad unit IDs. These always fill with a test ad,
/// so the app is demonstrably functional even before a real AdMob
/// account is wired up in the Admin Dashboard's Ads & Config page.
class _TestAdUnitIds {
  static String get banner =>
      Platform.isIOS ? 'ca-app-pub-3940256099942544/2934735716' : 'ca-app-pub-3940256099942544/6300978111';
  static String get interstitial =>
      Platform.isIOS ? 'ca-app-pub-3940256099942544/4411468910' : 'ca-app-pub-3940256099942544/1033173712';
  static String get rewarded =>
      Platform.isIOS ? 'ca-app-pub-3940256099942544/1712485313' : 'ca-app-pub-3940256099942544/5224354917';
}

/// Wraps google_mobile_ads for the whole app: one place that knows how
/// to load/show Banner, Interstitial, and Rewarded ads, using whatever
/// ad unit IDs the Admin Dashboard has configured (falling back to
/// Google's test IDs when a field is left blank).
class AdService extends ChangeNotifier {
  bool _initialized = false;
  bool adsEnabled = true;

  String? bannerAdUnitId;
  String? _interstitialAdUnitId;
  String? _rewardedAdUnitId;

  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  int _playbackCount = 0;

  Future<void> initialize(AppConfigModel config) async {
    if (_initialized) return;
    await MobileAds.instance.initialize();
    _initialized = true;

    adsEnabled = config.adsEnabled;
    bannerAdUnitId = config.admobBannerId.isNotEmpty ? config.admobBannerId : _TestAdUnitIds.banner;
    _interstitialAdUnitId =
        config.admobInterstitialId.isNotEmpty ? config.admobInterstitialId : _TestAdUnitIds.interstitial;
    _rewardedAdUnitId = config.admobRewardedId.isNotEmpty ? config.admobRewardedId : _TestAdUnitIds.rewarded;

    if (adsEnabled) {
      _loadInterstitial();
      _loadRewarded();
    }
    notifyListeners();
  }

  void _loadInterstitial() {
    final adUnitId = _interstitialAdUnitId;
    if (!adsEnabled || adUnitId == null) return;
    InterstitialAd.load(
      adUnitId: adUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _interstitialAd = ad,
        onAdFailedToLoad: (error) => debugPrint('[AdService] Interstitial failed to load: $error'),
      ),
    );
  }

  void _loadRewarded() {
    final adUnitId = _rewardedAdUnitId;
    if (!adsEnabled || adUnitId == null) return;
    RewardedAd.load(
      adUnitId: adUnitId,
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) => _rewardedAd = ad,
        onAdFailedToLoad: (error) => debugPrint('[AdService] Rewarded ad failed to load: $error'),
      ),
    );
  }

  /// Called after a piece of VOD content finishes playing. Shows an
  /// interstitial every other time so it never feels punishing.
  void maybeShowInterstitial() {
    if (!adsEnabled) return;
    _playbackCount++;
    if (_playbackCount % 2 != 0) return;

    final ad = _interstitialAd;
    if (ad == null) {
      _loadInterstitial();
      return;
    }

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _interstitialAd = null;
        _loadInterstitial();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _interstitialAd = null;
        _loadInterstitial();
      },
    );
    _interstitialAd = null;
    ad.show();
  }

  /// Shows a Rewarded Ad. [onEarned] fires only once the person watches
  /// through and actually earns the reward — this is what unlocks HD
  /// for Free-tier users (see content_details/video_player screens).
  Future<void> showRewardedAd({required VoidCallback onEarned, required VoidCallback onFailed}) async {
    final ad = _rewardedAd;
    if (!adsEnabled || ad == null) {
      onFailed();
      _loadRewarded();
      return;
    }

    var earned = false;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        _rewardedAd = null;
        _loadRewarded();
        if (!earned) onFailed();
      },
      onAdFailedToShowFullScreenContent: (ad, error) {
        ad.dispose();
        _rewardedAd = null;
        _loadRewarded();
        onFailed();
      },
    );

    _rewardedAd = null;
    await ad.show(
      onUserEarnedReward: (adWithoutView, reward) {
        earned = true;
        onEarned();
      },
    );
  }
}
