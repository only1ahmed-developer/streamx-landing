import 'dart:convert';
import 'package:http/http.dart' as http;
import '../core/config/api_config.dart';
import '../models/content_model.dart';
import '../models/homepage_bundle_model.dart';

class ContentListResult {
  final List<ContentModel> items;
  final int page;
  final int pages;
  final int total;

  const ContentListResult({
    required this.items,
    required this.page,
    required this.pages,
    required this.total,
  });

  bool get hasMore => page < pages;
}

/// Talks to the "Unified Endpoint" the backend exposes (Grade 2), so
/// every category — Movies, TV, Music, Sports, Anime, Education — is
/// fetched through the exact same three methods.
class ContentService {
  Future<HomepageBundle> fetchHomepage() async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/content/homepage');
    final response = await http.get(uri).timeout(const Duration(seconds: 12));

    if (response.statusCode != 200) {
      throw Exception('Failed to load homepage (${response.statusCode})');
    }
    final body = json.decode(response.body) as Map<String, dynamic>;
    return HomepageBundle.fromJson(body['data'] as Map<String, dynamic>);
  }

  Future<ContentListResult> fetchList({
    String? type,
    String? filter,
    String? genre,
    String? search,
    String? sort,
    bool? isLive,
    String? liveStatus,
    int page = 1,
    int limit = 20,
  }) async {
    final params = <String, String>{
      'page': '$page',
      'limit': '$limit',
      if (type != null && type.isNotEmpty) 'type': type,
      if (filter != null && filter.isNotEmpty) 'filter': filter,
      if (genre != null && genre.isNotEmpty) 'genre': genre,
      if (search != null && search.isNotEmpty) 'search': search,
      if (sort != null && sort.isNotEmpty) 'sort': sort,
      if (isLive == true) 'isLive': 'true',
      if (liveStatus != null && liveStatus.isNotEmpty) 'liveStatus': liveStatus,
    };

    final uri = Uri.parse('${ApiConfig.baseUrl}/content').replace(queryParameters: params);
    final response = await http.get(uri).timeout(const Duration(seconds: 12));

    if (response.statusCode != 200) {
      throw Exception('Failed to load content (${response.statusCode})');
    }

    final body = json.decode(response.body) as Map<String, dynamic>;
    final items = (body['data'] as List? ?? [])
        .map((e) => ContentModel.fromJson(e as Map<String, dynamic>))
        .toList();
    final pagination = body['pagination'] as Map<String, dynamic>? ?? const {};

    return ContentListResult(
      items: items,
      page: (pagination['page'] as num?)?.toInt() ?? page,
      pages: (pagination['pages'] as num?)?.toInt() ?? 1,
      total: (pagination['total'] as num?)?.toInt() ?? items.length,
    );
  }

  Future<ContentModel> fetchDetails(String id) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/content/$id');
    final response = await http.get(uri).timeout(const Duration(seconds: 12));

    if (response.statusCode == 404) {
      throw Exception('This title could not be found.');
    }
    if (response.statusCode != 200) {
      throw Exception('Failed to load details (${response.statusCode})');
    }

    final body = json.decode(response.body) as Map<String, dynamic>;
    return ContentModel.fromJson(body['data'] as Map<String, dynamic>);
  }

  /// Confirms with the backend that a Rewarded Ad was watched, granting
  /// a temporary HD unlock (see accessControl.js). Called by the video
  /// player right after AdService reports the reward was earned.
  Future<void> unlockHd(String contentId, String token) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/content/$contentId/unlock-hd');
    final response = await http
        .post(uri, headers: {'Authorization': 'Bearer $token'})
        .timeout(const Duration(seconds: 12));
    final body = json.decode(response.body) as Map<String, dynamic>;

    if (response.statusCode != 200 || body['success'] != true) {
      throw Exception(body['message'] as String? ?? 'Could not unlock HD.');
    }
  }

  /// Asks the backend for a direct, tier-gated download URL. Requires a
  /// signed-in user's token (Grade 8's AuthService).
  Future<Map<String, dynamic>> fetchDownloadUrl(String contentId, String quality, String token) async {
    final uri = Uri.parse('${ApiConfig.baseUrl}/content/$contentId/download')
        .replace(queryParameters: {'quality': quality});
    final response = await http
        .get(uri, headers: {'Authorization': 'Bearer $token'})
        .timeout(const Duration(seconds: 12));
    final body = json.decode(response.body) as Map<String, dynamic>;

    if (response.statusCode != 200 || body['success'] != true) {
      throw Exception(body['message'] as String? ?? 'Download is not available (${response.statusCode}).');
    }
    return body['data'] as Map<String, dynamic>;
  }
}
