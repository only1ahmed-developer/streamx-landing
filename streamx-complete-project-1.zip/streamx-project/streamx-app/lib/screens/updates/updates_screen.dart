import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../services/app_config_service.dart';

class UpdatesScreen extends StatefulWidget {
  const UpdatesScreen({super.key});

  @override
  State<UpdatesScreen> createState() => _UpdatesScreenState();
}

class _UpdatesScreenState extends State<UpdatesScreen> {
  String _installedVersion = '';

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((info) {
      if (mounted) setState(() => _installedVersion = info.version);
    });
  }

  Future<void> _open(String url) async {
    if (url.isEmpty) return;
    final uri = Uri.tryParse(url);
    if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final service = context.watch<AppConfigService>();
    final config = service.config;

    if (service.isLoading && config == null) {
      return const Center(child: CircularProgressIndicator(color: AppColors.cyan));
    }

    if (config == null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.wifi_off_rounded, color: AppColors.muted, size: 40),
              const SizedBox(height: 12),
              Text(service.error ?? 'Unable to load updates.', textAlign: TextAlign.center),
              const SizedBox(height: 16),
              OutlinedButton(
                onPressed: () => context.read<AppConfigService>().fetchConfig(),
                child: const Text('Try again'),
              ),
            ],
          ),
        ),
      );
    }

    final updateAvailable = config.latestVersion != _installedVersion && _installedVersion.isNotEmpty;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.system_update_rounded, color: AppColors.cyan),
                    const SizedBox(width: 10),
                    Text('App version', style: Theme.of(context).textTheme.titleMedium),
                  ],
                ),
                const SizedBox(height: 12),
                _InfoRow(label: 'Installed', value: _installedVersion.isEmpty ? '—' : _installedVersion),
                _InfoRow(label: 'Latest available', value: config.latestVersion),
                if (updateAvailable) ...[
                  const SizedBox(height: 12),
                  if (config.updateMessage.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Text(config.updateMessage, style: Theme.of(context).textTheme.bodySmall),
                    ),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () => _open(config.apkDownloadUrl),
                      child: const Text('Download update'),
                    ),
                  ),
                ] else
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text("You're up to date.", style: Theme.of(context).textTheme.bodySmall),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        if (config.telegramChannelUrl.isNotEmpty)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.send_rounded, color: AppColors.accent),
                      const SizedBox(width: 10),
                      Text('Community & updates', style: Theme.of(context).textTheme.titleMedium),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Join our Telegram channel to get notified the moment new movies, shows, or live events drop.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton(
                      onPressed: () => _open(config.telegramChannelUrl),
                      child: const Text('Join Telegram channel'),
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
        ],
      ),
    );
  }
}
