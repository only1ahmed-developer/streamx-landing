import 'package:flutter/material.dart';
import '../../models/homepage_bundle_model.dart';
import '../../services/content_service.dart';
import '../../widgets/content_row.dart';
import '../../widgets/error_state.dart';
import '../../widgets/hero_banner.dart';
import '../../widgets/loading_indicator.dart';
import '../categories/category_content_screen.dart';

const _categoryDisplayMeta = <String, ({String title, IconData icon})>{
  'movies': (title: 'Movies', icon: Icons.movie_rounded),
  'tv': (title: 'TV Shows', icon: Icons.tv_rounded),
  'music': (title: 'Music', icon: Icons.music_note_rounded),
  'sports': (title: 'Sports', icon: Icons.sports_soccer_rounded),
  'education': (title: 'Education', icon: Icons.school_rounded),
  'anime': (title: 'Animation', icon: Icons.animation_rounded),
};

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _service = ContentService();
  HomepageBundle? _bundle;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final bundle = await _service.fetchHomepage();
      setState(() {
        _bundle = bundle;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _error = 'Could not load StreamX right now. Pull down to try again.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) return const LoadingIndicator();

    if (_error != null && _bundle == null) {
      return ErrorState(message: _error!, onRetry: _load);
    }

    final bundle = _bundle!;

    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 24),
        children: [
          HeroBanner(items: bundle.hero),
          const SizedBox(height: 4),
          for (final row in bundle.rows)
            ContentRow(
              title: row.title,
              items: row.items,
              onSeeAll: () {
                final meta = _categoryDisplayMeta[row.category];
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CategoryContentScreen(
                      category: row.category,
                      title: meta?.title ?? row.title,
                      icon: meta?.icon ?? Icons.category_rounded,
                    ),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }
}
