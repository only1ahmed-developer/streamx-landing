import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../models/download_item_model.dart';
import '../../services/download_service.dart';
import '../../widgets/section_placeholder.dart';
import '../player/offline_player_screen.dart';

class DownloadsScreen extends StatefulWidget {
  const DownloadsScreen({super.key});

  @override
  State<DownloadsScreen> createState() => _DownloadsScreenState();
}

class _DownloadsScreenState extends State<DownloadsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DownloadService>().loadSaved();
    });
  }

  String _formatBytes(int bytes) {
    if (bytes <= 0) return '0 MB';
    final mb = bytes / (1024 * 1024);
    return '${mb.toStringAsFixed(mb >= 100 ? 0 : 1)} MB';
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<DownloadService>(
      builder: (context, service, _) {
        final items = service.downloads;

        if (items.isEmpty) {
          return const SectionPlaceholder(
            icon: Icons.download_rounded,
            title: 'No downloads yet',
            note: 'Download movies, shows, and music from their details page to watch offline.\n'
                'Sign in to download — arrives in Grade 8.',
          );
        }

        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: items.length,
          separatorBuilder: (_, __) => const SizedBox(height: 10),
          itemBuilder: (_, i) => _DownloadTile(
            item: items[i],
            formatBytes: _formatBytes,
            onPlay: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => OfflinePlayerScreen(filePath: items[i].localPath, title: items[i].title),
              ),
            ),
            onCancel: () => service.cancelDownload(items[i].contentId),
            onDelete: () => service.deleteDownload(items[i].contentId),
          ),
        );
      },
    );
  }
}

class _DownloadTile extends StatelessWidget {
  final DownloadItem item;
  final String Function(int) formatBytes;
  final VoidCallback onPlay;
  final VoidCallback onCancel;
  final VoidCallback onDelete;

  const _DownloadTile({
    required this.item,
    required this.formatBytes,
    required this.onPlay,
    required this.onCancel,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: item.poster.isNotEmpty
                ? CachedNetworkImage(imageUrl: item.poster, width: 56, height: 56, fit: BoxFit.cover)
                : Container(
                    width: 56,
                    height: 56,
                    color: AppColors.surface2,
                    child: const Icon(Icons.movie_rounded, color: AppColors.muted),
                  ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                const SizedBox(height: 4),
                Text(
                  '${item.quality.toUpperCase()} · ${formatBytes(item.totalBytes)}',
                  style: const TextStyle(color: AppColors.muted, fontSize: 11.5),
                ),
                if (item.status == DownloadStatus.downloading) ...[
                  const SizedBox(height: 8),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: item.progress > 0 ? item.progress : null,
                      minHeight: 4,
                      backgroundColor: AppColors.surface2,
                      valueColor: const AlwaysStoppedAnimation(AppColors.cyan),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('${(item.progress * 100).toStringAsFixed(0)}%',
                      style: const TextStyle(color: AppColors.muted, fontSize: 10.5)),
                ] else if (item.status == DownloadStatus.failed)
                  const Padding(
                    padding: EdgeInsets.only(top: 4),
                    child: Text('Download failed', style: TextStyle(color: AppColors.accent, fontSize: 11.5)),
                  ),
              ],
            ),
          ),
          Column(
            children: [
              if (item.status == DownloadStatus.completed)
                IconButton(
                  icon: const Icon(Icons.play_circle_fill_rounded, color: AppColors.accent),
                  onPressed: onPlay,
                )
              else if (item.status == DownloadStatus.downloading)
                IconButton(
                  icon: const Icon(Icons.close_rounded, color: AppColors.muted),
                  onPressed: onCancel,
                ),
              IconButton(
                icon: const Icon(Icons.delete_outline_rounded, color: AppColors.muted, size: 20),
                onPressed: onDelete,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
