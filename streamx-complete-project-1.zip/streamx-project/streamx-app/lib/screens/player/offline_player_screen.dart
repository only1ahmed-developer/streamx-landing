import 'dart:io';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../../core/theme/app_colors.dart';
import '../../widgets/error_state.dart';
import '../../widgets/loading_indicator.dart';

class OfflinePlayerScreen extends StatefulWidget {
  final String filePath;
  final String title;

  const OfflinePlayerScreen({super.key, required this.filePath, required this.title});

  @override
  State<OfflinePlayerScreen> createState() => _OfflinePlayerScreenState();
}

class _OfflinePlayerScreenState extends State<OfflinePlayerScreen> {
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    WakelockPlus.enable();
    _init();
  }

  Future<void> _init() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    final file = File(widget.filePath);
    if (!await file.exists()) {
      setState(() {
        _isLoading = false;
        _error = 'This downloaded file could not be found. It may have been removed.';
      });
      return;
    }

    try {
      final controller = VideoPlayerController.file(file);
      await controller.initialize();
      final chewie = ChewieController(
        videoPlayerController: controller,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        materialProgressColors: ChewieProgressColors(
          playedColor: AppColors.accent,
          handleColor: AppColors.accent,
          backgroundColor: AppColors.surface2,
          bufferedColor: AppColors.muted,
        ),
      );
      if (!mounted) return;
      setState(() {
        _videoController = controller;
        _chewieController = chewie;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = 'Unable to play this downloaded file.';
      });
    }
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    _chewieController?.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: Center(child: _buildBody()),
    );
  }

  Widget _buildBody() {
    if (_error != null) return ErrorState(message: _error!, onRetry: _init);
    if (_isLoading || _chewieController == null || _videoController == null) {
      return const LoadingIndicator();
    }
    final aspectRatio = _videoController!.value.aspectRatio;
    return AspectRatio(
      aspectRatio: aspectRatio == 0 ? 16 / 9 : aspectRatio,
      child: Chewie(controller: _chewieController!),
    );
  }
}
