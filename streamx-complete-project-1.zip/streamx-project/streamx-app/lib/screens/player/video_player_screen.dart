import 'dart:async';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/subtitle_parser.dart';
import '../../models/content_model.dart';
import '../../services/ad_service.dart';
import '../../services/auth_service.dart';
import '../../services/content_service.dart';
import '../../widgets/error_state.dart';
import '../../widgets/loading_indicator.dart';

class VideoPlayerScreen extends StatefulWidget {
  final ContentModel content;
  const VideoPlayerScreen({super.key, required this.content});

  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  final _contentService = ContentService();

  late ContentModel _content;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  String? _quality;
  bool _isLoading = true;
  String? _error;

  List<SubtitleCue> _subtitles = [];
  String? _activeCaptionLabel;
  bool _captionsLoading = false;
  Timer? _progressTimer;

  Map<String, String> get _availableQualities {
    final sl = _content.streamLinks;
    return {
      if (sl?.hd != null) 'hd': sl!.hd!,
      if (sl?.sd != null) 'sd': sl!.sd!,
      if (sl?.uhd != null) 'uhd': sl!.uhd!,
    };
  }

  @override
  void initState() {
    super.initState();
    _content = widget.content;
    WakelockPlus.enable();
    final qualities = _availableQualities;
    if (qualities.isEmpty) {
      _isLoading = false;
      _error = 'No playable video source is available for this title yet.';
    } else {
      _loadQuality(qualities.containsKey('hd') ? 'hd' : qualities.keys.first);
    }
    _progressTimer = Timer.periodic(const Duration(seconds: 15), (_) => _saveProgress());
  }

  void _saveProgress() {
    final controller = _videoController;
    if (controller == null || !controller.value.isInitialized) return;
    final auth = context.read<AuthService>();
    if (!auth.isLoggedIn) return;
    auth.saveWatchProgress(_content.id, controller.value.position.inSeconds);
  }

  Future<void> _loadQuality(String quality) async {
    final url = _availableQualities[quality];
    if (url == null) return;

    setState(() {
      _isLoading = true;
      _error = null;
    });

    final oldChewie = _chewieController;
    final oldVideo = _videoController;

    try {
      final controller = VideoPlayerController.networkUrl(Uri.parse(url));
      await controller.initialize();

      final chewie = ChewieController(
        videoPlayerController: controller,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        materialProgressColors: ChewieProgressColors(
          playedColor: AppColors.accent,
          handleColor: AppColors.accent,
          backgroundColor: AppColors.surface2,
          bufferedColor: AppColors.muted,
        ),
      );

      if (!mounted) return;
      setState(() {
        _quality = quality;
        _videoController = controller;
        _chewieController = chewie;
        _isLoading = false;
      });

      oldChewie?.dispose();
      await oldVideo?.dispose();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = 'Unable to play this video. Try another quality or check your connection.';
      });
    }
  }

  Future<void> _loadCaptions(CaptionTrack track) async {
    setState(() => _captionsLoading = true);
    try {
      final cues = await fetchAndParseSubtitles(track.url);
      if (!mounted) return;
      setState(() {
        _subtitles = cues;
        _activeCaptionLabel = track.label.isNotEmpty ? track.label : track.language;
        _captionsLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => _captionsLoading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not load captions for that language.')),
      );
    }
  }

  void _clearCaptions() {
    setState(() {
      _subtitles = [];
      _activeCaptionLabel = null;
    });
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    _progressTimer?.cancel();
    _chewieController?.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  void _pickQuality() {
    final sl = _content.streamLinks;
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Quality', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
            for (final entry in _availableQualities.entries)
              ListTile(
                title: Text(entry.key.toUpperCase()),
                trailing: _quality == entry.key ? const Icon(Icons.check, color: AppColors.accent) : null,
                onTap: () {
                  Navigator.pop(context);
                  if (_quality != entry.key) _loadQuality(entry.key);
                },
              ),
            if (sl?.hdRequiresAd == true && !_availableQualities.containsKey('hd'))
              ListTile(
                title: const Text('HD'),
                trailing: const Icon(Icons.ondemand_video_rounded, color: AppColors.cyan, size: 18),
                subtitle: const Text('Watch a short ad to unlock', style: TextStyle(fontSize: 11)),
                onTap: () {
                  Navigator.pop(context);
                  _watchAdToUnlockHd();
                },
              ),
            if (sl?.uhdLocked == true && !_availableQualities.containsKey('uhd'))
              ListTile(
                title: const Text('4K'),
                trailing: const Icon(Icons.lock_outline_rounded, color: AppColors.muted, size: 18),
                subtitle: const Text('Requires the Super Streamer plan', style: TextStyle(fontSize: 11)),
                onTap: () {
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Contact us via the Telegram channel (Updates tab) to upgrade to Super Streamer.'),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _watchAdToUnlockHd() async {
    final auth = context.read<AuthService>();
    if (!auth.isLoggedIn || auth.token == null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Sign in from My Account to unlock HD with an ad.')));
      return;
    }

    await context.read<AdService>().showRewardedAd(
      onEarned: () async {
        try {
          await _contentService.unlockHd(_content.id, auth.token!);
          final refreshed = await _contentService.fetchDetails(_content.id);
          if (!mounted) return;
          setState(() => _content = refreshed);
          await _loadQuality('hd');
          if (!mounted) return;
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text('HD unlocked for the next 30 minutes!')));
        } catch (e) {
          if (!mounted) return;
          ScaffoldMessenger.of(context)
              .showSnackBar(const SnackBar(content: Text('Could not unlock HD. Please try again.')));
        }
      },
      onFailed: () {
        if (!mounted) return;
        ScaffoldMessenger.of(context)
            .showSnackBar(const SnackBar(content: Text('No ad is available right now. Please try again shortly.')));
      },
    );
  }

  void _pickCaptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Subtitles', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
            ListTile(
              title: const Text('Off'),
              trailing: _activeCaptionLabel == null ? const Icon(Icons.check, color: AppColors.accent) : null,
              onTap: () {
                Navigator.pop(context);
                _clearCaptions();
              },
            ),
            for (final track in _content.captions)
              ListTile(
                title: Text(track.label.isNotEmpty ? track.label : track.language),
                trailing:
                    _activeCaptionLabel == (track.label.isNotEmpty ? track.label : track.language)
                        ? const Icon(Icons.check, color: AppColors.accent)
                        : null,
                onTap: () {
                  Navigator.pop(context);
                  _loadCaptions(track);
                },
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(_content.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          if (_content.captions.isNotEmpty)
            IconButton(
              icon: _captionsLoading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.cyan),
                    )
                  : const Icon(Icons.closed_caption_outlined),
              onPressed: _pickCaptions,
            ),
          if (_availableQualities.isNotEmpty)
            IconButton(icon: const Icon(Icons.hd_rounded), onPressed: _pickQuality),
        ],
      ),
      body: Center(child: _buildBody()),
    );
  }

  Widget _buildBody() {
    if (_error != null) {
      return ErrorState(
        message: _error!,
        onRetry: () {
          final q = _availableQualities;
          if (q.isNotEmpty) _loadQuality(q.containsKey('hd') ? 'hd' : q.keys.first);
        },
      );
    }
    if (_isLoading || _chewieController == null || _videoController == null) {
      return const LoadingIndicator();
    }

    final aspectRatio = _videoController!.value.aspectRatio;

    return AspectRatio(
      aspectRatio: aspectRatio == 0 ? 16 / 9 : aspectRatio,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Chewie(controller: _chewieController!),
          if (_subtitles.isNotEmpty)
            Positioned(
              left: 12,
              right: 12,
              bottom: 56,
              child: AnimatedBuilder(
                animation: _videoController!,
                builder: (context, _) {
                  final cue = findActiveCue(_subtitles, _videoController!.value.position);
                  if (cue == null) return const SizedBox.shrink();
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      cue.text,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.3),
                    ),
                  );
                },
              ),
            ),
        ],
      ),
    );
  }
}
