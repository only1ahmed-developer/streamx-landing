import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../services/audio_player_service.dart';

class AudioPlayerScreen extends StatelessWidget {
  const AudioPlayerScreen({super.key});

  String _formatDuration(Duration d) {
    final minutes = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final service = context.watch<AudioPlayerService>();
    final track = service.currentTrack;

    if (track == null) {
      return const Scaffold(body: Center(child: Text('Nothing is playing.')));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Now Playing')),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Column(
          children: [
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: track.displayPoster.isNotEmpty
                  ? CachedNetworkImage(
                      imageUrl: track.displayPoster,
                      width: 240,
                      height: 240,
                      fit: BoxFit.cover,
                    )
                  : Container(
                      width: 240,
                      height: 240,
                      color: AppColors.surface2,
                      child: const Icon(Icons.music_note_rounded, size: 60, color: AppColors.muted),
                    ),
            ),
            const SizedBox(height: 28),
            Text(track.title, style: Theme.of(context).textTheme.titleLarge, textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(
              track.cast.isNotEmpty
                  ? track.cast.first
                  : (track.director.isNotEmpty ? track.director : 'Unknown artist'),
              style: const TextStyle(color: AppColors.muted, fontSize: 13),
            ),
            const SizedBox(height: 24),
            StreamBuilder<Duration>(
              stream: service.positionStream,
              builder: (context, posSnapshot) {
                final position = posSnapshot.data ?? Duration.zero;
                return StreamBuilder<Duration?>(
                  stream: service.durationStream,
                  builder: (context, durSnapshot) {
                    final duration = durSnapshot.data ?? Duration.zero;
                    final maxMs = duration.inMilliseconds > 0 ? duration.inMilliseconds.toDouble() : 1.0;
                    final valueMs = position.inMilliseconds.clamp(0, maxMs.toInt()).toDouble();

                    return Column(
                      children: [
                        SliderTheme(
                          data: SliderThemeData(
                            activeTrackColor: AppColors.accent,
                            inactiveTrackColor: AppColors.surface2,
                            thumbColor: AppColors.accent,
                            overlayColor: AppColors.accent.withOpacity(0.2),
                            trackHeight: 3,
                          ),
                          child: Slider(
                            min: 0,
                            max: maxMs,
                            value: valueMs,
                            onChanged: (v) => service.seek(Duration(milliseconds: v.toInt())),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(_formatDuration(position),
                                  style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                              Text(_formatDuration(duration),
                                  style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                            ],
                          ),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
            const SizedBox(height: 12),
            StreamBuilder<PlayerState>(
              stream: service.playerStateStream,
              builder: (context, snapshot) {
                final playing = snapshot.data?.playing ?? service.isPlaying;
                return Container(
                  width: 68,
                  height: 68,
                  decoration: const BoxDecoration(color: AppColors.accent, shape: BoxShape.circle),
                  child: IconButton(
                    iconSize: 34,
                    icon: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, color: Colors.white),
                    onPressed: service.togglePlayPause,
                  ),
                );
              },
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
