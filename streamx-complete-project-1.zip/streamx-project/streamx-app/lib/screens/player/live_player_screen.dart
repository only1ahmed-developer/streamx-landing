import 'package:cached_network_image/cached_network_image.dart';
import 'package:chewie/chewie.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../../core/theme/app_colors.dart';
import '../../models/content_model.dart';
import '../../widgets/error_state.dart';
import '../../widgets/loading_indicator.dart';

class LivePlayerScreen extends StatefulWidget {
  final ContentModel content;
  const LivePlayerScreen({super.key, required this.content});

  @override
  State<LivePlayerScreen> createState() => _LivePlayerScreenState();
}

class _LivePlayerScreenState extends State<LivePlayerScreen> {
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;
  bool _isLoading = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.content.liveStatus == 'live' || widget.content.liveStatus == null) {
      WakelockPlus.enable();
      _loadStream();
    }
  }

  Future<void> _loadStream() async {
    final sl = widget.content.streamLinks;
    final url = sl?.hd ?? sl?.sd ?? sl?.uhd;
    if (url == null) {
      setState(() => _error = 'This live stream link is not available yet.');
      return;
    }

    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final controller = VideoPlayerController.networkUrl(Uri.parse(url));
      await controller.initialize();
      final chewie = ChewieController(
        videoPlayerController: controller,
        autoPlay: true,
        looping: false,
        allowFullScreen: true,
        allowMuting: true,
        materialProgressColors: ChewieProgressColors(
          playedColor: AppColors.accent,
          handleColor: AppColors.accent,
          backgroundColor: AppColors.surface2,
          bufferedColor: AppColors.muted,
        ),
      );
      if (!mounted) return;
      setState(() {
        _videoController = controller;
        _chewieController = chewie;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _error = 'Unable to connect to the live stream.';
      });
    }
  }

  @override
  void dispose() {
    WakelockPlus.disable();
    _chewieController?.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(widget.content.title, maxLines: 1, overflow: TextOverflow.ellipsis),
      ),
      body: Center(child: _buildBody()),
    );
  }

  Widget _buildBody() {
    final status = widget.content.liveStatus;

    if (status == 'upcoming') {
      return _StatusMessage(
        icon: Icons.schedule_rounded,
        title: 'Not started yet',
        message: widget.content.startTime != null
            ? 'Starts ${_formatDateTime(widget.content.startTime!)}'
            : 'This event has not started yet.',
        backdrop: widget.content.displayBackdrop,
      );
    }
    if (status == 'ended') {
      return _StatusMessage(
        icon: Icons.stop_circle_outlined,
        title: 'Event ended',
        message: 'This live event has ended.',
        backdrop: widget.content.displayBackdrop,
      );
    }

    if (_error != null) return ErrorState(message: _error!, onRetry: _loadStream);
    if (_isLoading || _chewieController == null || _videoController == null) {
      return const LoadingIndicator();
    }

    final aspectRatio = _videoController!.value.aspectRatio;

    return Stack(
      alignment: Alignment.topLeft,
      children: [
        AspectRatio(
          aspectRatio: aspectRatio == 0 ? 16 / 9 : aspectRatio,
          child: Chewie(controller: _chewieController!),
        ),
        Positioned(
          top: 12,
          left: 12,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(color: AppColors.accent, borderRadius: BorderRadius.circular(4)),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.circle, size: 8, color: Colors.white),
                SizedBox(width: 4),
                Text('LIVE', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

String _formatDateTime(DateTime dt) {
  final local = dt.toLocal();
  final h = local.hour.toString().padLeft(2, '0');
  final m = local.minute.toString().padLeft(2, '0');
  return '${local.day}/${local.month}/${local.year} at $h:$m';
}

class _StatusMessage extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  final String backdrop;

  const _StatusMessage({
    required this.icon,
    required this.title,
    required this.message,
    this.backdrop = '',
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        if (backdrop.isNotEmpty)
          Opacity(
            opacity: 0.35,
            child: CachedNetworkImage(imageUrl: backdrop, fit: BoxFit.cover),
          )
        else
          Container(color: AppColors.base),
        Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 48, color: AppColors.cyan),
                const SizedBox(height: 14),
                Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: Colors.white)),
                const SizedBox(height: 8),
                Text(message, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted)),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
