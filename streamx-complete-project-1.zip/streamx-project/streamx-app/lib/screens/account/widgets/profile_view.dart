import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/theme/app_colors.dart';
import '../../../models/user_model.dart';
import '../../../services/auth_service.dart';
import '../../../widgets/content_card.dart';

const _tierLabels = {
  'free': 'Free',
  'streamer': 'Streamer',
  'super_streamer': 'Super Streamer',
};

class ProfileView extends StatelessWidget {
  const ProfileView({super.key});

  Future<void> _addProfile(BuildContext context) async {
    final nameController = TextEditingController();
    bool isKids = false;

    final result = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setDialogState) => AlertDialog(
          backgroundColor: AppColors.surface,
          title: const Text('Add profile'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: nameController,
                decoration: const InputDecoration(labelText: 'Profile name'),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Checkbox(
                    value: isKids,
                    onChanged: (v) => setDialogState(() => isKids = v ?? false),
                  ),
                  const Text('Kids profile', style: TextStyle(fontSize: 13)),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('Cancel')),
            TextButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('Add')),
          ],
        ),
      ),
    );

    if (result == true && nameController.text.trim().isNotEmpty && context.mounted) {
      await context.read<AuthService>().addProfile(name: nameController.text.trim(), isKidsProfile: isKids);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthService>();
    final user = auth.currentUser;
    if (user == null) return const SizedBox.shrink();

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _HeaderCard(user: user),
        const SizedBox(height: 20),
        Text('My Watchlist', style: Theme.of(context).textTheme.titleMedium),
        const SizedBox(height: 10),
        if (user.watchlist.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Text('Nothing saved yet. Tap Watchlist on any title to add it here.',
                style: TextStyle(color: AppColors.muted, fontSize: 12.5)),
          )
        else
          SizedBox(
            height: 190,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: user.watchlist.length,
              separatorBuilder: (_, __) => const SizedBox(width: 10),
              itemBuilder: (_, i) => ContentCard(item: user.watchlist[i]),
            ),
          ),
        const SizedBox(height: 24),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Profiles', style: Theme.of(context).textTheme.titleMedium),
            TextButton.icon(
              onPressed: () => _addProfile(context),
              icon: const Icon(Icons.add_rounded, size: 18, color: AppColors.cyan),
              label: const Text('Add', style: TextStyle(color: AppColors.cyan, fontSize: 12.5)),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Wrap(
          spacing: 10,
          runSpacing: 10,
          children: user.profiles
              .map((p) => Chip(
                    avatar: Icon(
                      p.isKidsProfile ? Icons.child_care_rounded : Icons.person_rounded,
                      size: 16,
                      color: AppColors.cyan,
                    ),
                    label: Text(p.name, style: const TextStyle(fontSize: 12.5)),
                    backgroundColor: AppColors.surface2,
                    side: const BorderSide(color: AppColors.border),
                  ))
              .toList(),
        ),
        const SizedBox(height: 28),
        OutlinedButton.icon(
          onPressed: () => context.read<AuthService>().logout(),
          icon: const Icon(Icons.logout_rounded, size: 18, color: AppColors.accent),
          label: const Text('Log out', style: TextStyle(color: AppColors.accent)),
        ),
        const SizedBox(height: 24),
      ],
    );
  }
}

class _HeaderCard extends StatelessWidget {
  final UserModel user;
  const _HeaderCard({required this.user});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: AppColors.surface2,
            child: Text(
              user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: AppColors.textPrimary),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user.name, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                const SizedBox(height: 2),
                Text(user.email, style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: user.subscriptionType == 'free' ? AppColors.surface2 : AppColors.accent,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        _tierLabels[user.subscriptionType] ?? 'Free',
                        style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: Colors.white),
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (user.subscriptionType == 'free')
                      GestureDetector(
                        onTap: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Contact us via the Telegram channel (Updates tab) to upgrade your plan.'),
                            ),
                          );
                        },
                        child: const Text('Upgrade', style: TextStyle(color: AppColors.cyan, fontSize: 11.5)),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
