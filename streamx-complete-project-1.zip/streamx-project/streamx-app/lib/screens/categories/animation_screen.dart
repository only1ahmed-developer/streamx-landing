import 'package:flutter/material.dart';
import 'category_content_screen.dart';

class AnimationScreen extends StatelessWidget {
  const AnimationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const CategoryContentScreen(category: 'anime', title: 'Animation', icon: Icons.animation_rounded);
  }
}
