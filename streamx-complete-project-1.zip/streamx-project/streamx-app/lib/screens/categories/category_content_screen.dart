import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../models/content_model.dart';
import '../../services/content_service.dart';
import '../../widgets/content_card.dart';
import '../../widgets/error_state.dart';
import '../../widgets/loading_indicator.dart';

class CategoryContentScreen extends StatefulWidget {
  final String category; // backend enum value: movies, tv, music, sports, anime, education...
  final String title; // human-readable page title
  final IconData icon;

  const CategoryContentScreen({
    super.key,
    required this.category,
    required this.title,
    required this.icon,
  });

  @override
  State<CategoryContentScreen> createState() => _CategoryContentScreenState();
}

const _sortOptions = <String, String>{
  'newest': 'Newest',
  'trending': 'Trending',
  'rating': 'Top rated',
  'az': 'A–Z',
};

class _CategoryContentScreenState extends State<CategoryContentScreen> {
  final _service = ContentService();
  final _searchController = TextEditingController();
  final _scrollController = ScrollController();

  List<ContentModel> _items = [];
  int _page = 1;
  bool _hasMore = true;
  bool _isLoading = true;
  bool _isLoadingMore = false;
  String? _error;
  String _sort = 'newest';
  String _search = '';

  @override
  void initState() {
    super.initState();
    _load(reset: true);
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_isLoadingMore || !_hasMore) return;
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 300) {
      _load();
    }
  }

  Future<void> _load({bool reset = false}) async {
    if (reset) {
      setState(() {
        _isLoading = true;
        _error = null;
        _page = 1;
        _items = [];
        _hasMore = true;
      });
    } else {
      if (!_hasMore) return;
      setState(() => _isLoadingMore = true);
    }

    try {
      final result = await _service.fetchList(
        type: widget.category,
        search: _search,
        sort: _sort,
        page: reset ? 1 : _page + 1,
        limit: 18,
      );
      setState(() {
        _items = reset ? result.items : [..._items, ...result.items];
        _page = result.page;
        _hasMore = result.hasMore;
        _isLoading = false;
        _isLoadingMore = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _isLoadingMore = false;
        _error = 'Could not load ${widget.title}. Check your connection.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    style: const TextStyle(fontSize: 14),
                    decoration: InputDecoration(
                      hintText: 'Search ${widget.title.toLowerCase()}…',
                      hintStyle: const TextStyle(color: AppColors.muted, fontSize: 14),
                      prefixIcon: const Icon(Icons.search_rounded, color: AppColors.muted, size: 20),
                      filled: true,
                      fillColor: AppColors.surface2,
                      contentPadding: const EdgeInsets.symmetric(vertical: 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: const BorderSide(color: AppColors.border),
                      ),
                    ),
                    onSubmitted: (v) {
                      _search = v.trim();
                      _load(reset: true);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                PopupMenuButton<String>(
                  color: AppColors.surface2,
                  icon: const Icon(Icons.sort_rounded, color: AppColors.muted),
                  initialValue: _sort,
                  onSelected: (v) {
                    _sort = v;
                    _load(reset: true);
                  },
                  itemBuilder: (_) => _sortOptions.entries
                      .map((e) => PopupMenuItem(value: e.key, child: Text(e.value)))
                      .toList(),
                ),
              ],
            ),
          ),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) return const LoadingIndicator();

    if (_error != null && _items.isEmpty) {
      return ErrorState(message: _error!, onRetry: () => _load(reset: true));
    }

    if (_items.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(widget.icon, size: 40, color: AppColors.muted),
            const SizedBox(height: 12),
            Text('No ${widget.title.toLowerCase()} found yet.', style: const TextStyle(color: AppColors.muted)),
          ],
        ),
      );
    }

    return RefreshIndicator(
      color: AppColors.cyan,
      backgroundColor: AppColors.surface,
      onRefresh: () => _load(reset: true),
      child: GridView.builder(
        controller: _scrollController,
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisSpacing: 14,
          crossAxisSpacing: 10,
          childAspectRatio: 0.56,
        ),
        itemCount: _items.length + (_isLoadingMore ? 3 : 0),
        itemBuilder: (_, i) {
          if (i >= _items.length) {
            return Container(
              decoration: BoxDecoration(color: AppColors.surface2, borderRadius: BorderRadius.circular(10)),
            );
          }
          return ContentCard(item: _items[i], width: double.infinity);
        },
      ),
    );
  }
}
