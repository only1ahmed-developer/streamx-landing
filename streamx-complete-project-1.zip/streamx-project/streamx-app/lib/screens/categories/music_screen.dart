import 'package:flutter/material.dart';
import 'category_content_screen.dart';

class MusicScreen extends StatelessWidget {
  const MusicScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const CategoryContentScreen(category: 'music', title: 'Music', icon: Icons.music_note_rounded);
  }
}
