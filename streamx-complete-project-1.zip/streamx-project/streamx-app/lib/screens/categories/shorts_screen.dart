import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../models/content_model.dart';
import '../../services/content_service.dart';
import '../../widgets/error_state.dart';
import '../../widgets/loading_indicator.dart';
import '../../widgets/shorts_video_tile.dart';

class ShortsScreen extends StatefulWidget {
  const ShortsScreen({super.key});

  @override
  State<ShortsScreen> createState() => _ShortsScreenState();
}

class _ShortsScreenState extends State<ShortsScreen> {
  final _service = ContentService();
  final _pageController = PageController();

  List<ContentModel> _items = [];
  int _currentIndex = 0;
  int _page = 1;
  bool _hasMore = true;
  bool _isLoading = true;
  bool _isLoadingMore = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load(reset: true);
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<void> _load({bool reset = false}) async {
    if (reset) {
      setState(() {
        _isLoading = true;
        _error = null;
      });
    } else {
      if (!_hasMore || _isLoadingMore) return;
      _isLoadingMore = true;
    }

    try {
      final result = await _service.fetchList(
        type: 'shorts',
        sort: 'newest',
        page: reset ? 1 : _page + 1,
        limit: 8,
      );
      setState(() {
        _items = reset ? result.items : [..._items, ...result.items];
        _page = result.page;
        _hasMore = result.hasMore;
        _isLoading = false;
        _isLoadingMore = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _isLoadingMore = false;
        _error = 'Could not load Shorts. Check your connection.';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(backgroundColor: Colors.black, body: LoadingIndicator());
    }
    if (_error != null && _items.isEmpty) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(child: ErrorState(message: _error!, onRetry: () => _load(reset: true))),
      );
    }
    if (_items.isEmpty) {
      return const Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Text('No Shorts yet — check back soon.', style: TextStyle(color: AppColors.muted)),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          PageView.builder(
            scrollDirection: Axis.vertical,
            controller: _pageController,
            itemCount: _items.length,
            onPageChanged: (i) {
              setState(() => _currentIndex = i);
              if (i >= _items.length - 3) _load();
            },
            itemBuilder: (_, i) => ShortsVideoTile(item: _items[i], isActive: i == _currentIndex),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(left: 8, top: 4),
              child: IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
