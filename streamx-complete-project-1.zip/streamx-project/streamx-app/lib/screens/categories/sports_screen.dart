import 'package:flutter/material.dart';
import 'category_content_screen.dart';

class SportsScreen extends StatelessWidget {
  const SportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const CategoryContentScreen(category: 'sports', title: 'Sports', icon: Icons.sports_soccer_rounded);
  }
}
