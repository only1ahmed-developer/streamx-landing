import 'package:flutter/material.dart';
import 'category_content_screen.dart';

class TvShowsScreen extends StatelessWidget {
  const TvShowsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const CategoryContentScreen(category: 'tv', title: 'TV Shows', icon: Icons.tv_rounded);
  }
}
