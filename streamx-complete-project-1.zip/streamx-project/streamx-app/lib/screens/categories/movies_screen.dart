import 'package:flutter/material.dart';
import 'category_content_screen.dart';

class MoviesScreen extends StatelessWidget {
  const MoviesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const CategoryContentScreen(category: 'movies', title: 'Movies', icon: Icons.movie_rounded);
  }
}
