import 'package:flutter/material.dart';
import 'category_content_screen.dart';

class EducationScreen extends StatelessWidget {
  const EducationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const CategoryContentScreen(category: 'education', title: 'Education', icon: Icons.school_rounded);
  }
}
