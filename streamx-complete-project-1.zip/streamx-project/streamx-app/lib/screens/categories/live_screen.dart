import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../models/content_model.dart';
import '../../services/content_service.dart';
import '../../widgets/error_state.dart';
import '../../widgets/live_event_card.dart';
import '../../widgets/loading_indicator.dart';

class LiveScreen extends StatefulWidget {
  const LiveScreen({super.key});

  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  final _service = ContentService();

  final Map<String, List<ContentModel>> _cache = {};
  final Map<String, bool> _loading = {'live': true, 'upcoming': true, 'ended': true};
  final Map<String, String?> _errors = {};

  static const _tabs = ['live', 'upcoming', 'ended'];
  static const _tabLabels = ['Live Now', 'Upcoming', 'Ended'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _tabs.length, vsync: this);
    for (final status in _tabs) {
      _load(status);
    }
  }

  Future<void> _load(String status) async {
    setState(() => _loading[status] = true);
    try {
      final result = await _service.fetchList(isLive: true, liveStatus: status, sort: 'newest', limit: 30);
      setState(() {
        _cache[status] = result.items;
        _loading[status] = false;
        _errors[status] = null;
      });
    } catch (e) {
      setState(() {
        _loading[status] = false;
        _errors[status] = 'Could not load live events. Check your connection.';
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Live'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: AppColors.accent,
          labelColor: AppColors.textPrimary,
          unselectedLabelColor: AppColors.muted,
          tabs: _tabLabels.map((t) => Tab(text: t)).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: _tabs.map((status) => _buildTab(status)).toList(),
      ),
    );
  }

  Widget _buildTab(String status) {
    if (_loading[status] == true && _cache[status] == null) {
      return const LoadingIndicator();
    }
    if (_errors[status] != null && (_cache[status] == null || _cache[status]!.isEmpty)) {
      return ErrorState(message: _errors[status]!, onRetry: () => _load(status));
    }
    final items = _cache[status] ?? [];
    if (items.isEmpty) {
      return Center(
        child: Text(
          status == 'live' ? 'Nothing is live right now.' : 'No $status events yet.',
          style: const TextStyle(color: AppColors.muted),
        ),
      );
    }
    return RefreshIndicator(
      color: AppColors.cyan,
      onRefresh: () => _load(status),
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: items.length,
        itemBuilder: (_, i) => LiveEventCard(item: items[i]),
      ),
    );
  }
}
