import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_colors.dart';
import '../../core/routes/app_routes.dart';
import '../../services/ad_service.dart';
import '../../services/app_config_service.dart';
import '../../services/auth_service.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _bootstrap());
  }

  Future<void> _bootstrap() async {
    final configService = context.read<AppConfigService>();
    final authService = context.read<AuthService>();

    await Future.wait([
      configService.fetchConfig(),
      authService.loadSession(),
    ]);

    if (!mounted) return;

    final config = configService.config;

    if (config != null) {
      // Fire-and-forget: ad SDK init shouldn't block the person from
      // reaching the app if it's slow or the network is flaky.
      unawaited(context.read<AdService>().initialize(config));
    }
    if (config != null && config.maintenanceMode) {
      Navigator.pushReplacementNamed(
        context,
        AppRoutes.maintenance,
        arguments: config.maintenanceMessage,
      );
      return;
    }

    // A stricter force-update flow (blocking access below
    // minSupportedVersion) can be added later by comparing
    // config.minSupportedVersion against the installed version here —
    // the Updates tab already surfaces the same data today.
    Navigator.pushReplacementNamed(context, AppRoutes.main);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.base,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RichText(
              text: const TextSpan(
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700),
                children: [
                  TextSpan(text: 'Stream', style: TextStyle(color: AppColors.textPrimary)),
                  TextSpan(text: 'X', style: TextStyle(color: AppColors.accent)),
                ],
              ),
            ),
            const SizedBox(height: 28),
            const SizedBox(
              width: 22,
              height: 22,
              child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.cyan),
            ),
          ],
        ),
      ),
    );
  }
}
