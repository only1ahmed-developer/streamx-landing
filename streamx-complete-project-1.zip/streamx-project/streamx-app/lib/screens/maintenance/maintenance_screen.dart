import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';

class MaintenanceScreen extends StatelessWidget {
  final String message;
  const MaintenanceScreen({super.key, required this.message});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.base,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.build_circle_outlined, size: 56, color: AppColors.cyan),
              const SizedBox(height: 20),
              Text('Under maintenance', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 10),
              Text(
                message.isEmpty ? 'StreamX is under maintenance. Please check back soon.' : message,
                textAlign: TextAlign.center,
                style: const TextStyle(color: AppColors.muted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
