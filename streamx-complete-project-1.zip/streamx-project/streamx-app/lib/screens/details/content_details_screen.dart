import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../models/content_model.dart';
import '../../services/ad_service.dart';
import '../../services/auth_service.dart';
import '../../services/audio_player_service.dart';
import '../../services/content_service.dart';
import '../../services/download_service.dart';
import '../../widgets/error_state.dart';
import '../../widgets/loading_indicator.dart';
import '../player/audio_player_screen.dart';
import '../player/live_player_screen.dart';
import '../player/video_player_screen.dart';

class ContentDetailsScreen extends StatefulWidget {
  final String contentId;
  const ContentDetailsScreen({super.key, required this.contentId});

  @override
  State<ContentDetailsScreen> createState() => _ContentDetailsScreenState();
}

class _ContentDetailsScreenState extends State<ContentDetailsScreen> {
  final _service = ContentService();
  ContentModel? _item;
  bool _isLoading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    try {
      final item = await _service.fetchDetails(widget.contentId);
      setState(() {
        _item = item;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
        _error = 'Could not load this title. Check your connection.';
      });
    }
  }

  void _snack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _openTrailer() async {
    final url = _item?.trailerUrl ?? '';
    if (url.isEmpty) return;
    final uri = Uri.tryParse(url);
    if (uri != null) await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  Future<void> _handlePlay(ContentModel item) async {
    // Live events (any category) get the live-aware player: it handles
    // Upcoming / Live / Ended states on top of the same video stack.
    if (item.isLive) {
      Navigator.push(context, MaterialPageRoute(builder: (_) => LivePlayerScreen(content: item)));
      return;
    }

    // Music plays through the persistent audio service so a MiniPlayer
    // can keep playing while the person browses the rest of the app.
    if (item.category == 'music') {
      final url = item.streamLinks?.hd ?? item.streamLinks?.sd ?? item.streamLinks?.uhd;
      if (url == null) {
        _snack('No audio source is available for this track yet.');
        return;
      }
      await context.read<AudioPlayerService>().playTrack(item, url);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioPlayerScreen()));
      return;
    }

    // Everything else (Movies, TV, Sports, News, Education, Anime, Kids,
    // Gaming, Shorts) uses the standard in-app video player.
    final hasSource = item.streamLinks?.sd != null ||
        item.streamLinks?.hd != null ||
        item.streamLinks?.uhd != null;
    if (!hasSource) {
      _snack('No playable source is available for this title yet.');
      return;
    }
    await Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPlayerScreen(content: item)));

    if (!mounted) return;
    final tier = context.read<AuthService>().currentUser?.subscriptionType ?? 'free';
    if (tier == 'free') {
      context.read<AdService>().maybeShowInterstitial();
    }
  }

  Future<void> _handleWatchlist(ContentModel item) async {
    final auth = context.read<AuthService>();
    if (!auth.isLoggedIn) {
      _snack('Sign in from My Account to save titles.');
      return;
    }
    final alreadySaved = auth.isInWatchlist(item.id);
    final success = alreadySaved
        ? await auth.removeFromWatchlist(item.id)
        : await auth.addToWatchlist(item.id);

    if (!mounted) return;
    _snack(success
        ? (alreadySaved ? 'Removed from Watchlist.' : 'Added to Watchlist.')
        : 'Something went wrong. Please try again.');
  }

  Future<String?> _pickDownloadQuality(ContentModel item) async {
    final available = <String>[
      if (item.streamLinks?.sd != null) 'sd',
      if (item.streamLinks?.hd != null) 'hd',
      if (item.streamLinks?.uhd != null) 'uhd',
    ];
    if (available.isEmpty) return null;
    if (available.length == 1) return available.first;

    return showModalBottomSheet<String>(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Download quality', style: TextStyle(fontWeight: FontWeight.w600)),
            ),
            for (final q in available)
              ListTile(title: Text(q.toUpperCase()), onTap: () => Navigator.pop(context, q)),
          ],
        ),
      ),
    );
  }

  Future<void> _handleDownload(ContentModel item) async {
    if (!item.allowDownload) {
      _snack('Downloads are not enabled for this title.');
      return;
    }

    final auth = context.read<AuthService>();
    if (!auth.isLoggedIn || auth.token == null) {
      _snack('Sign in from My Account to download.');
      return;
    }

    final quality = await _pickDownloadQuality(item);
    if (quality == null) {
      _snack('No downloadable source is available for this title.');
      return;
    }

    try {
      final data = await _service.fetchDownloadUrl(item.id, quality, auth.token!);
      if (!mounted) return;
      await context.read<DownloadService>().startDownload(item, data['url'] as String, quality);
      if (!mounted) return;
      _snack('Download started — check the Downloads tab.');
    } catch (e) {
      if (!mounted) return;
      _snack(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: LoadingIndicator());
    }
    if (_error != null || _item == null) {
      return Scaffold(
        appBar: AppBar(),
        body: ErrorState(message: _error ?? 'Something went wrong.', onRetry: _load),
      );
    }

    final item = _item!;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 260,
            pinned: true,
            backgroundColor: AppColors.base,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  if (item.displayBackdrop.isNotEmpty)
                    CachedNetworkImage(imageUrl: item.displayBackdrop, fit: BoxFit.cover)
                  else
                    Container(color: AppColors.surface2),
                  DecoratedBox(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [Colors.transparent, AppColors.base],
                        stops: const [0.4, 1.0],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(item.title, style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 8),
                  _MetaRow(item: item),
                  if (item.genres.isNotEmpty) ...[
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: item.genres
                          .map((g) => Chip(
                                label: Text(g, style: const TextStyle(fontSize: 11)),
                                backgroundColor: AppColors.surface2,
                                side: const BorderSide(color: AppColors.border),
                                padding: EdgeInsets.zero,
                                visualDensity: VisualDensity.compact,
                              ))
                          .toList(),
                    ),
                  ],
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => _handlePlay(item),
                          icon: const Icon(Icons.play_arrow_rounded),
                          label: const Text('Play'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      if (item.trailerUrl.isNotEmpty)
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: _openTrailer,
                            icon: const Icon(Icons.smart_display_outlined, size: 18),
                            label: const Text('Trailer'),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _handleDownload(item),
                          icon: const Icon(Icons.download_outlined, size: 18),
                          label: const Text('Download'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Consumer<AuthService>(
                          builder: (context, auth, _) {
                            final saved = auth.isInWatchlist(item.id);
                            return OutlinedButton.icon(
                              onPressed: () => _handleWatchlist(item),
                              icon: Icon(
                                saved ? Icons.check_rounded : Icons.add_rounded,
                                size: 18,
                                color: saved ? AppColors.success : null,
                              ),
                              label: Text(saved ? 'Saved' : 'Watchlist'),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  if (item.streamLinks != null && item.streamLinks!.hdRequiresAd) ...[
                    const SizedBox(height: 10),
                    _NoticeBanner(
                      icon: Icons.ondemand_video_rounded,
                      text: 'Watch a short ad to unlock HD, or upgrade to Streamer for ad-free HD.',
                    ),
                  ],
                  if (item.streamLinks != null && item.streamLinks!.uhdLocked) ...[
                    const SizedBox(height: 10),
                    _NoticeBanner(
                      icon: Icons.diamond_outlined,
                      text: '4K is available on the Super Streamer plan.',
                    ),
                  ],
                  if (item.synopsis.isNotEmpty) ...[
                    const SizedBox(height: 22),
                    Text('Synopsis', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    Text(item.synopsis, style: const TextStyle(color: AppColors.textPrimary, height: 1.5)),
                  ],
                  if (item.cast.isNotEmpty) ...[
                    const SizedBox(height: 18),
                    Text('Cast', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 6),
                    Text(item.cast.join(', '), style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                  ],
                  if (item.director.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text('Director', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 6),
                    Text(item.director, style: const TextStyle(color: AppColors.muted, fontSize: 13)),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _MetaRow extends StatelessWidget {
  final ContentModel item;
  const _MetaRow({required this.item});

  @override
  Widget build(BuildContext context) {
    final parts = <String>[
      if (item.releaseYear != null) '${item.releaseYear}',
      if (item.duration > 0) '${item.duration} min',
      if (item.rating > 0) '★ ${item.rating.toStringAsFixed(1)}',
      item.ageRating,
      if (item.accessLevel != 'free') item.accessLevel.replaceAll('_', ' ').toUpperCase(),
    ];

    return Text(
      parts.join('  •  '),
      style: const TextStyle(color: AppColors.muted, fontSize: 13),
    );
  }
}

class _NoticeBanner extends StatelessWidget {
  final IconData icon;
  final String text;
  const _NoticeBanner({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: AppColors.cyan),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12.5, color: AppColors.textPrimary))),
        ],
      ),
    );
  }
}
