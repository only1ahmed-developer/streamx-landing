import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../core/routes/app_routes.dart';
import '../core/theme/app_colors.dart';
import '../models/content_model.dart';

class ContentCard extends StatelessWidget {
  final ContentModel item;
  final double width;

  const ContentCard({super.key, required this.item, this.width = 128});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, AppRoutes.contentDetails, arguments: item.id),
      child: SizedBox(
        width: width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            AspectRatio(
              aspectRatio: 2 / 3,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: item.displayPoster.isNotEmpty
                        ? CachedNetworkImage(
                            imageUrl: item.displayPoster,
                            fit: BoxFit.cover,
                            placeholder: (_, __) => Container(color: AppColors.surface2),
                            errorWidget: (_, __, ___) => _fallback(),
                          )
                        : _fallback(),
                  ),
                  if (item.isTrending)
                    Positioned(
                      top: 6,
                      left: 6,
                      child: _Badge(label: 'TRENDING', color: AppColors.accent),
                    ),
                  if (item.isLive && item.liveStatus == 'live')
                    Positioned(
                      top: 6,
                      left: 6,
                      child: _Badge(label: 'LIVE', color: AppColors.success),
                    ),
                  if (item.ageRating == '18+')
                    const Positioned(
                      bottom: 6,
                      right: 6,
                      child: _Badge(label: '18+', color: AppColors.warning),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Text(
              item.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500, color: AppColors.textPrimary),
            ),
          ],
        ),
      ),
    );
  }

  Widget _fallback() {
    return Container(
      color: AppColors.surface2,
      child: const Icon(Icons.image_not_supported_outlined, color: AppColors.muted),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  const _Badge({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(4)),
      child: Text(
        label,
        style: const TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Colors.white),
      ),
    );
  }
}
