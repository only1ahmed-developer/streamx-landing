import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import '../core/routes/app_routes.dart';
import '../core/theme/app_colors.dart';
import '../models/content_model.dart';

class LiveEventCard extends StatelessWidget {
  final ContentModel item;
  const LiveEventCard({super.key, required this.item});

  String _formatStart(DateTime? dt) {
    if (dt == null) return '';
    final local = dt.toLocal();
    final h = local.hour.toString().padLeft(2, '0');
    final m = local.minute.toString().padLeft(2, '0');
    return '${local.day}/${local.month}/${local.year} · $h:$m';
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, AppRoutes.contentDetails, arguments: item.id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: const BorderRadius.horizontal(left: Radius.circular(12)),
              child: SizedBox(
                width: 110,
                height: 78,
                child: item.displayBackdrop.isNotEmpty
                    ? CachedNetworkImage(imageUrl: item.displayBackdrop, fit: BoxFit.cover)
                    : Container(color: AppColors.surface2, child: const Icon(Icons.sensors_rounded, color: AppColors.muted)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)),
                    const SizedBox(height: 6),
                    _StatusChip(status: item.liveStatus, startTime: item.startTime, formatStart: _formatStart),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String? status;
  final DateTime? startTime;
  final String Function(DateTime?) formatStart;

  const _StatusChip({required this.status, required this.startTime, required this.formatStart});

  @override
  Widget build(BuildContext context) {
    if (status == 'live') {
      return const Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.circle, size: 8, color: AppColors.accent),
          SizedBox(width: 4),
          Text('LIVE NOW', style: TextStyle(color: AppColors.accent, fontSize: 11, fontWeight: FontWeight.w700)),
        ],
      );
    }
    if (status == 'ended') {
      return const Text('Ended', style: TextStyle(color: AppColors.muted, fontSize: 11.5));
    }
    return Text(
      startTime != null ? 'Starts ${formatStart(startTime)}' : 'Upcoming',
      style: const TextStyle(color: AppColors.cyan, fontSize: 11.5),
    );
  }
}
