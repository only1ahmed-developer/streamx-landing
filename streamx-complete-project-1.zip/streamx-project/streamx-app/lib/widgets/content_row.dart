import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../models/content_model.dart';
import 'content_card.dart';

class ContentRow extends StatelessWidget {
  final String title;
  final List<ContentModel> items;
  final VoidCallback? onSeeAll;

  const ContentRow({super.key, required this.title, required this.items, this.onSeeAll});

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 12, 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(title, style: Theme.of(context).textTheme.titleMedium),
              if (onSeeAll != null)
                TextButton(
                  onPressed: onSeeAll,
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text('See all', style: TextStyle(color: AppColors.cyan, fontSize: 12.5)),
                      Icon(Icons.chevron_right_rounded, color: AppColors.cyan, size: 18),
                    ],
                  ),
                ),
            ],
          ),
        ),
        SizedBox(
          height: 210,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) => ContentCard(item: items[i]),
          ),
        ),
        const SizedBox(height: 12),
      ],
    );
  }
}
