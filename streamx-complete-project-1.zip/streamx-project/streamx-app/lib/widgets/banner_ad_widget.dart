import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_colors.dart';
import '../services/ad_service.dart';

class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  BannerAd? _bannerAd;
  bool _isLoaded = false;
  bool _requested = false;

  void _loadBanner(String adUnitId) {
    _requested = true;
    final ad = BannerAd(
      adUnitId: adUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          if (mounted) setState(() => _isLoaded = true);
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
        },
      ),
    );
    ad.load();
    _bannerAd = ad;
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final adService = context.watch<AdService>();
    if (!adService.adsEnabled || adService.bannerAdUnitId == null) return const SizedBox.shrink();

    if (!_requested) {
      // Defer the actual ad request to a frame after build to avoid
      // calling setState during the initial build phase.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && !_requested) _loadBanner(adService.bannerAdUnitId!);
      });
    }

    if (_bannerAd == null || !_isLoaded) return const SizedBox.shrink();

    return Container(
      alignment: Alignment.center,
      width: _bannerAd!.size.width.toDouble(),
      height: _bannerAd!.size.height.toDouble(),
      color: AppColors.surface,
      child: AdWidget(ad: _bannerAd!),
    );
  }
}
