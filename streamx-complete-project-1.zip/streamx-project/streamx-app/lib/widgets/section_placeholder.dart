import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';

/// A calm, on-brand placeholder for sections whose data-driven content
/// is built in a later Grade (per the agreed roadmap), so the full
/// navigation graph is real and demoable today even before every screen
/// is wired to the API.
class SectionPlaceholder extends StatelessWidget {
  final IconData icon;
  final String title;
  final String note;

  const SectionPlaceholder({
    super.key,
    required this.icon,
    required this.title,
    this.note = '',
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: AppColors.surface2,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Icon(icon, size: 28, color: AppColors.cyan),
            ),
            const SizedBox(height: 18),
            Text(title, style: Theme.of(context).textTheme.titleLarge),
            if (note.isNotEmpty) ...[
              const SizedBox(height: 8),
              Text(
                note,
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ],
        ),
      ),
    );
  }
}
