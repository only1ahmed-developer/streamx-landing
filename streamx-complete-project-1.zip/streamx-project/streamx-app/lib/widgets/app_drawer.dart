import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../core/routes/app_routes.dart';

class _DrawerItem {
  final String label;
  final IconData icon;
  final String route;
  const _DrawerItem(this.label, this.icon, this.route);
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  static const _items = [
    _DrawerItem('Movies', Icons.movie_rounded, AppRoutes.movies),
    _DrawerItem('TV Shows', Icons.tv_rounded, AppRoutes.tvShows),
    _DrawerItem('Music', Icons.music_note_rounded, AppRoutes.music),
    _DrawerItem('Sports', Icons.sports_soccer_rounded, AppRoutes.sports),
    _DrawerItem('Animation', Icons.animation_rounded, AppRoutes.animation),
    _DrawerItem('Education', Icons.school_rounded, AppRoutes.education),
    _DrawerItem('Live', Icons.sensors_rounded, AppRoutes.live),
    _DrawerItem('Shorts', Icons.smartphone_rounded, AppRoutes.shorts),
  ];

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: AppColors.surface,
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 56, 20, 20),
            color: AppColors.surface2,
            child: RichText(
              text: const TextSpan(
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                children: [
                  TextSpan(text: 'Stream', style: TextStyle(color: AppColors.textPrimary)),
                  TextSpan(text: 'X', style: TextStyle(color: AppColors.accent)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          for (final item in _items)
            ListTile(
              leading: Icon(item.icon, color: AppColors.muted),
              title: Text(item.label, style: const TextStyle(color: AppColors.textPrimary)),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, item.route);
              },
            ),
        ],
      ),
    );
  }
}
