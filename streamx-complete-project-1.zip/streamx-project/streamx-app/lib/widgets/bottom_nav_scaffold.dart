import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_colors.dart';
import '../screens/account/my_account_screen.dart';
import '../screens/downloads/downloads_screen.dart';
import '../screens/home/home_screen.dart';
import '../screens/updates/updates_screen.dart';
import '../services/auth_service.dart';
import 'app_drawer.dart';
import 'banner_ad_widget.dart';
import 'mini_player.dart';

/// The persistent shell of the app: Bottom Navigation Bar for the four
/// primary destinations (Home, Downloads, Updates, My Account) plus a
/// Sidebar Drawer for the eight content categories — exactly the
/// combination agreed on during planning.
class BottomNavScaffold extends StatefulWidget {
  const BottomNavScaffold({super.key});

  @override
  State<BottomNavScaffold> createState() => _BottomNavScaffoldState();
}

class _BottomNavScaffoldState extends State<BottomNavScaffold> {
  int _index = 0;

  static const _titles = ['StreamX', 'Downloads', 'Updates', 'My Account'];

  final _screens = const [
    HomeScreen(),
    DownloadsScreen(),
    UpdatesScreen(),
    MyAccountScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.base,
      appBar: AppBar(title: Text(_titles[_index])),
      drawer: const AppDrawer(),
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const MiniPlayer(),
          Consumer<AuthService>(
            builder: (context, auth, _) {
              final tier = auth.currentUser?.subscriptionType ?? 'free';
              return tier == 'free' ? const BannerAdWidget() : const SizedBox.shrink();
            },
          ),
          BottomNavigationBar(
            currentIndex: _index,
            onTap: (i) => setState(() => _index = i),
            items: const [
              BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Home'),
              BottomNavigationBarItem(icon: Icon(Icons.download_rounded), label: 'Downloads'),
              BottomNavigationBarItem(icon: Icon(Icons.notifications_rounded), label: 'Updates'),
              BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'My Account'),
            ],
          ),
        ],
      ),
    );
  }
}
