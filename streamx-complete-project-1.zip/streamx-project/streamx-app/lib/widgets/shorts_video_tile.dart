import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import '../core/theme/app_colors.dart';
import '../models/content_model.dart';
import 'loading_indicator.dart';

/// A single page inside the vertical Shorts feed. Flutter's
/// PageView.builder only keeps nearby pages mounted (via
/// SliverFillViewport), so this widget's own initState/dispose is
/// naturally called as the person swipes — that's what keeps memory
/// bounded without any manual controller-map bookkeeping.
class ShortsVideoTile extends StatefulWidget {
  final ContentModel item;
  final bool isActive;

  const ShortsVideoTile({super.key, required this.item, required this.isActive});

  @override
  State<ShortsVideoTile> createState() => _ShortsVideoTileState();
}

class _ShortsVideoTileState extends State<ShortsVideoTile> {
  VideoPlayerController? _controller;
  bool _showPauseIcon = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final sl = widget.item.streamLinks;
    final url = sl?.sd ?? sl?.hd ?? sl?.uhd;
    if (url == null) return;

    final controller = VideoPlayerController.networkUrl(Uri.parse(url));
    try {
      await controller.initialize();
      await controller.setLooping(true);
      if (!mounted) {
        controller.dispose();
        return;
      }
      setState(() => _controller = controller);
      if (widget.isActive) controller.play();
    } catch (_) {
      controller.dispose();
    }
  }

  @override
  void didUpdateWidget(covariant ShortsVideoTile oldWidget) {
    super.didUpdateWidget(oldWidget);
    final controller = _controller;
    if (controller == null) return;
    if (widget.isActive && !oldWidget.isActive) {
      controller.play();
    } else if (!widget.isActive && oldWidget.isActive) {
      controller.pause();
      controller.seekTo(Duration.zero);
    }
  }

  void _togglePlayPause() {
    final controller = _controller;
    if (controller == null) return;
    setState(() {
      if (controller.value.isPlaying) {
        controller.pause();
        _showPauseIcon = true;
      } else {
        controller.play();
        _showPauseIcon = false;
      }
    });
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;

    return GestureDetector(
      onTap: _togglePlayPause,
      child: Container(
        color: Colors.black,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (controller != null && controller.value.isInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: controller.value.size.width,
                  height: controller.value.size.height,
                  child: VideoPlayer(controller),
                ),
              )
            else if (widget.item.displayPoster.isNotEmpty)
              CachedNetworkImage(imageUrl: widget.item.displayPoster, fit: BoxFit.cover)
            else
              const ColoredBox(color: AppColors.surface2),
            if (controller == null) const LoadingIndicator(),
            if (_showPauseIcon)
              const Center(
                child: Icon(Icons.play_arrow_rounded, color: Colors.white70, size: 72),
              ),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black.withOpacity(0.7)],
                  stops: const [0.6, 1.0],
                ),
              ),
            ),
            Positioned(
              left: 16,
              right: 70,
              bottom: 28,
              child: Text(
                widget.item.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
