import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_colors.dart';
import '../screens/player/audio_player_screen.dart';
import '../services/audio_player_service.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final service = context.watch<AudioPlayerService>();
    final track = service.currentTrack;
    if (track == null) return const SizedBox.shrink();

    return GestureDetector(
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioPlayerScreen())),
      child: Container(
        height: 56,
        color: AppColors.surface2,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: track.displayPoster.isNotEmpty
                  ? CachedNetworkImage(imageUrl: track.displayPoster, width: 38, height: 38, fit: BoxFit.cover)
                  : Container(
                      width: 38,
                      height: 38,
                      color: AppColors.surface,
                      child: const Icon(Icons.music_note_rounded, size: 18, color: AppColors.muted),
                    ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                track.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
              ),
            ),
            StreamBuilder<PlayerState>(
              stream: service.playerStateStream,
              builder: (context, snapshot) {
                final playing = snapshot.data?.playing ?? service.isPlaying;
                return IconButton(
                  icon: Icon(
                    playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                    color: AppColors.textPrimary,
                  ),
                  onPressed: service.togglePlayPause,
                );
              },
            ),
            IconButton(
              icon: const Icon(Icons.close_rounded, color: AppColors.muted, size: 20),
              onPressed: service.stop,
            ),
          ],
        ),
      ),
    );
  }
}
