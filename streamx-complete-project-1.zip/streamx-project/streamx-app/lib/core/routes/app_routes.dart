import 'package:flutter/material.dart';
import '../../screens/splash/splash_screen.dart';
import '../../screens/maintenance/maintenance_screen.dart';
import '../../widgets/bottom_nav_scaffold.dart';
import '../../screens/categories/movies_screen.dart';
import '../../screens/categories/tv_shows_screen.dart';
import '../../screens/categories/music_screen.dart';
import '../../screens/categories/sports_screen.dart';
import '../../screens/categories/animation_screen.dart';
import '../../screens/categories/education_screen.dart';
import '../../screens/categories/live_screen.dart';
import '../../screens/categories/shorts_screen.dart';
import '../../screens/details/content_details_screen.dart';

class AppRoutes {
  AppRoutes._();

  static const splash = '/';
  static const main = '/main';
  static const maintenance = '/maintenance';

  static const movies = '/movies';
  static const tvShows = '/tv-shows';
  static const music = '/music';
  static const sports = '/sports';
  static const animation = '/animation';
  static const education = '/education';
  static const live = '/live';
  static const shorts = '/shorts';
  static const contentDetails = '/content-details';

  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splash:
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case main:
        return MaterialPageRoute(builder: (_) => const BottomNavScaffold());
      case maintenance:
        final message = settings.arguments as String? ?? '';
        return MaterialPageRoute(builder: (_) => MaintenanceScreen(message: message));
      case movies:
        return MaterialPageRoute(builder: (_) => const MoviesScreen());
      case tvShows:
        return MaterialPageRoute(builder: (_) => const TvShowsScreen());
      case music:
        return MaterialPageRoute(builder: (_) => const MusicScreen());
      case sports:
        return MaterialPageRoute(builder: (_) => const SportsScreen());
      case animation:
        return MaterialPageRoute(builder: (_) => const AnimationScreen());
      case education:
        return MaterialPageRoute(builder: (_) => const EducationScreen());
      case live:
        return MaterialPageRoute(builder: (_) => const LiveScreen());
      case shorts:
        return MaterialPageRoute(builder: (_) => const ShortsScreen());
      case contentDetails:
        final id = settings.arguments as String;
        return MaterialPageRoute(builder: (_) => ContentDetailsScreen(contentId: id));
      default:
        return MaterialPageRoute(
          builder: (_) => const Scaffold(body: Center(child: Text('Page not found'))),
        );
    }
  }
}
