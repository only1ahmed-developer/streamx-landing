import 'package:http/http.dart' as http;

/// One subtitle line with its on-screen time window.
class SubtitleCue {
  final Duration start;
  final Duration end;
  final String text;

  const SubtitleCue({required this.start, required this.end, required this.text});
}

/// Fetches a caption file (.srt or .vtt) and parses it into cues.
/// Written as a small self-contained parser rather than depending on a
/// third-party subtitle package, since SRT/WebVTT's timing format is
/// simple and this keeps the player free of fragile dependencies.
Future<List<SubtitleCue>> fetchAndParseSubtitles(String url) async {
  final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 10));
  if (response.statusCode != 200) {
    throw Exception('Could not download captions (${response.statusCode})');
  }
  return parseSubtitleText(response.body);
}

/// Parses raw SRT or WebVTT text into a list of cues. Exposed
/// separately from [fetchAndParseSubtitles] so it can be unit tested
/// without a network call.
List<SubtitleCue> parseSubtitleText(String raw) {
  final cleaned = raw.replaceFirst(RegExp(r'^\uFEFF'), '').trim();
  final blocks = cleaned.split(RegExp(r'\r?\n\r?\n'));
  final cues = <SubtitleCue>[];

  final timeLineRegex = RegExp(
    r'(\d{2}:\d{2}:\d{2}[.,]\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}[.,]\d{3})',
  );

  for (final block in blocks) {
    final lines = block.trim().split(RegExp(r'\r?\n'));
    if (lines.isEmpty) continue;

    // Skip a leading "WEBVTT" header block or a numeric index line.
    final timeLineIndex = lines.indexWhere((l) => timeLineRegex.hasMatch(l));
    if (timeLineIndex == -1) continue;

    final match = timeLineRegex.firstMatch(lines[timeLineIndex])!;
    final start = _parseTimestamp(match.group(1)!);
    final end = _parseTimestamp(match.group(2)!);

    final textLines = lines.sublist(timeLineIndex + 1);
    final text = textLines.join('\n').replaceAll(RegExp(r'<[^>]*>'), '').trim();

    if (text.isNotEmpty) {
      cues.add(SubtitleCue(start: start, end: end, text: text));
    }
  }

  return cues;
}

Duration _parseTimestamp(String raw) {
  final normalized = raw.replaceAll(',', '.');
  final parts = normalized.split(':');
  final hours = int.parse(parts[0]);
  final minutes = int.parse(parts[1]);
  final secondsParts = parts[2].split('.');
  final seconds = int.parse(secondsParts[0]);
  final millis = secondsParts.length > 1 ? int.parse(secondsParts[1].padRight(3, '0').substring(0, 3)) : 0;

  return Duration(hours: hours, minutes: minutes, seconds: seconds, milliseconds: millis);
}

/// Finds the cue that should be showing at [position], or null if none.
SubtitleCue? findActiveCue(List<SubtitleCue> cues, Duration position) {
  for (final cue in cues) {
    if (position >= cue.start && position <= cue.end) return cue;
  }
  return null;
}
