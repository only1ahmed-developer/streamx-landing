import 'package:flutter/material.dart';

/// StreamX brand colors — deliberately the same palette as the Admin
/// Dashboard (Grade 3) so the whole product feels like one brand.
class AppColors {
  AppColors._();

  static const base = Color(0xFF0B0C10);
  static const surface = Color(0xFF14161C);
  static const surface2 = Color(0xFF1B1E27);
  static const border = Color(0xFF262A35);

  static const accent = Color(0xFFE5322D); // Signal Red
  static const cyan = Color(0xFF2DD4E8); // Broadcast Cyan

  static const textPrimary = Color(0xFFF5F6F8);
  static const muted = Color(0xFF8B90A0);

  static const success = Color(0xFF34D399);
  static const warning = Color(0xFFFBBF24);
}
