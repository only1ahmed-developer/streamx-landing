import 'package:flutter_dotenv/flutter_dotenv.dart';

/// Single place the app reads the backend's base URL from. Nothing else
/// in the app should hardcode a URL — this mirrors the backend's own
/// ApiConfig pattern for the external content API.
class ApiConfig {
  ApiConfig._();

  static String get baseUrl =>
      dotenv.env['API_BASE_URL'] ?? 'http://10.0.2.2:5000/api';
}
