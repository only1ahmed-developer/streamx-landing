/// A single subtitle/caption track for a piece of content.
class CaptionTrack {
  final String label;
  final String language;
  final String url;

  const CaptionTrack({required this.label, required this.language, required this.url});

  factory CaptionTrack.fromJson(Map<String, dynamic> json) {
    return CaptionTrack(
      label: json['label'] as String? ?? '',
      language: json['language'] as String? ?? '',
      url: json['url'] as String? ?? '',
    );
  }
}

/// The gated stream-link info returned only by GET /content/:id — the
/// backend already applies the Free/Streamer/Super Streamer access
/// rules before this reaches the app (see Grade 2's accessControl.js).
class StreamLinksInfo {
  final String? sd;
  final String? hd;
  final String? uhd;
  final bool hdRequiresAd;
  final bool uhdLocked;

  const StreamLinksInfo({
    this.sd,
    this.hd,
    this.uhd,
    this.hdRequiresAd = false,
    this.uhdLocked = false,
  });

  factory StreamLinksInfo.fromJson(Map<String, dynamic> json) {
    return StreamLinksInfo(
      sd: json['sd'] as String?,
      hd: json['hd'] as String?,
      uhd: json['uhd'] as String?,
      hdRequiresAd: json['hdRequiresAd'] as bool? ?? false,
      uhdLocked: json['uhdLocked'] as bool? ?? false,
    );
  }
}

class ContentModel {
  final String id;
  final String title;
  final String synopsis;
  final String category;
  final String subType;
  final List<String> genres;
  final String poster;
  final String backdrop;
  final String thumbnail;
  final String trailerUrl;
  final int duration;
  final bool allowDownload;
  final List<String> cast;
  final String director;
  final int? releaseYear;
  final String country;
  final String language;
  final double rating;
  final String ageRating;
  final bool isKidsFriendly;
  final String accessLevel;
  final bool isLive;
  final String? liveStatus;
  final DateTime? startTime;
  final int viewCount;
  final bool isTrending;
  final bool isFeatured;

  /// Only populated when this model came from GET /content/:id.
  final StreamLinksInfo? streamLinks;
  final List<CaptionTrack> captions;

  const ContentModel({
    required this.id,
    required this.title,
    required this.synopsis,
    required this.category,
    required this.subType,
    required this.genres,
    required this.poster,
    required this.backdrop,
    required this.thumbnail,
    required this.trailerUrl,
    required this.duration,
    required this.allowDownload,
    required this.cast,
    required this.director,
    required this.releaseYear,
    required this.country,
    required this.language,
    required this.rating,
    required this.ageRating,
    required this.isKidsFriendly,
    required this.accessLevel,
    required this.isLive,
    required this.liveStatus,
    required this.startTime,
    required this.viewCount,
    required this.isTrending,
    required this.isFeatured,
    this.streamLinks,
    this.captions = const [],
  });

  /// The image to use in posters/cards — falls back gracefully so the
  /// UI never shows a broken image if the admin only filled one field.
  String get displayPoster =>
      poster.isNotEmpty ? poster : (thumbnail.isNotEmpty ? thumbnail : backdrop);

  String get displayBackdrop =>
      backdrop.isNotEmpty ? backdrop : (poster.isNotEmpty ? poster : thumbnail);

  factory ContentModel.fromJson(Map<String, dynamic> json) {
    return ContentModel(
      id: (json['_id'] ?? json['id'] ?? '') as String,
      title: json['title'] as String? ?? 'Untitled',
      synopsis: json['synopsis'] as String? ?? '',
      category: json['category'] as String? ?? '',
      subType: json['subType'] as String? ?? '',
      genres: (json['genres'] as List?)?.map((e) => e.toString()).toList() ?? const [],
      poster: json['poster'] as String? ?? '',
      backdrop: json['backdrop'] as String? ?? '',
      thumbnail: json['thumbnail'] as String? ?? '',
      trailerUrl: json['trailerUrl'] as String? ?? '',
      duration: (json['duration'] as num?)?.toInt() ?? 0,
      allowDownload: json['allowDownload'] as bool? ?? false,
      cast: (json['cast'] as List?)?.map((e) => e.toString()).toList() ?? const [],
      director: json['director'] as String? ?? '',
      releaseYear: (json['releaseYear'] as num?)?.toInt(),
      country: json['country'] as String? ?? '',
      language: json['language'] as String? ?? '',
      rating: (json['rating'] as num?)?.toDouble() ?? 0,
      ageRating: json['ageRating'] as String? ?? 'G',
      isKidsFriendly: json['isKidsFriendly'] as bool? ?? false,
      accessLevel: json['accessLevel'] as String? ?? 'free',
      isLive: json['isLive'] as bool? ?? false,
      liveStatus: json['liveStatus'] as String?,
      startTime: json['startTime'] != null ? DateTime.tryParse(json['startTime'] as String) : null,
      viewCount: (json['viewCount'] as num?)?.toInt() ?? 0,
      isTrending: json['isTrending'] as bool? ?? false,
      isFeatured: json['isFeatured'] as bool? ?? false,
      streamLinks: json['streamLinks'] is Map<String, dynamic>
          ? StreamLinksInfo.fromJson(json['streamLinks'] as Map<String, dynamic>)
          : null,
      captions: (json['captions'] as List? ?? [])
          .map((e) => CaptionTrack.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}
