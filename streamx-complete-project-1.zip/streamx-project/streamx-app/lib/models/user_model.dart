import 'content_model.dart';

class UserProfile {
  final String id;
  final String name;
  final String avatar;
  final bool isKidsProfile;

  const UserProfile({
    required this.id,
    required this.name,
    required this.avatar,
    required this.isKidsProfile,
  });

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    return UserProfile(
      id: json['_id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      avatar: json['avatar'] as String? ?? '',
      isKidsProfile: json['isKidsProfile'] as bool? ?? false,
    );
  }
}

class UserModel {
  final String id;
  final String name;
  final String email;
  final String subscriptionType;
  final List<UserProfile> profiles;
  final List<ContentModel> watchlist;

  const UserModel({
    required this.id,
    required this.name,
    required this.email,
    required this.subscriptionType,
    required this.profiles,
    required this.watchlist,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['_id'] as String? ?? '',
      name: json['name'] as String? ?? '',
      email: json['email'] as String? ?? '',
      subscriptionType: json['subscriptionType'] as String? ?? 'free',
      profiles: (json['profiles'] as List? ?? [])
          .whereType<Map<String, dynamic>>()
          .map(UserProfile.fromJson)
          .toList(),
      // Only fully-populated Content documents (Maps) are usable here —
      // if the backend ever returns raw un-populated IDs (Strings) for
      // some reason, they're safely skipped rather than crashing the app.
      watchlist: (json['watchlist'] as List? ?? [])
          .whereType<Map<String, dynamic>>()
          .map(ContentModel.fromJson)
          .toList(),
    );
  }
}
