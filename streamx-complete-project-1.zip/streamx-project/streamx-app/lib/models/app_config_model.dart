class AppConfigModel {
  final String latestVersion;
  final String minSupportedVersion;
  final String updateMessage;
  final String apkDownloadUrl;
  final bool maintenanceMode;
  final String maintenanceMessage;
  final bool adsEnabled;
  final String admobBannerId;
  final String admobInterstitialId;
  final String admobRewardedId;
  final String customBannerImage;
  final String customBannerLink;
  final String telegramChannelUrl;

  const AppConfigModel({
    required this.latestVersion,
    required this.minSupportedVersion,
    required this.updateMessage,
    required this.apkDownloadUrl,
    required this.maintenanceMode,
    required this.maintenanceMessage,
    required this.adsEnabled,
    required this.admobBannerId,
    required this.admobInterstitialId,
    required this.admobRewardedId,
    required this.customBannerImage,
    required this.customBannerLink,
    required this.telegramChannelUrl,
  });

  factory AppConfigModel.fromJson(Map<String, dynamic> json) {
    return AppConfigModel(
      latestVersion: json['latestVersion'] as String? ?? '1.0.0',
      minSupportedVersion: json['minSupportedVersion'] as String? ?? '1.0.0',
      updateMessage: json['updateMessage'] as String? ?? '',
      apkDownloadUrl: json['apkDownloadUrl'] as String? ?? '',
      maintenanceMode: json['maintenanceMode'] as bool? ?? false,
      maintenanceMessage: json['maintenanceMessage'] as String? ?? '',
      adsEnabled: json['adsEnabled'] as bool? ?? true,
      admobBannerId: json['admobBannerId'] as String? ?? '',
      admobInterstitialId: json['admobInterstitialId'] as String? ?? '',
      admobRewardedId: json['admobRewardedId'] as String? ?? '',
      customBannerImage: json['customBannerImage'] as String? ?? '',
      customBannerLink: json['customBannerLink'] as String? ?? '',
      telegramChannelUrl: json['telegramChannelUrl'] as String? ?? '',
    );
  }
}
