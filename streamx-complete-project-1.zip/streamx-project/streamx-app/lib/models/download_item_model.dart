enum DownloadStatus { downloading, completed, failed }

class DownloadItem {
  final String contentId;
  final String title;
  final String poster;
  final String quality;
  final String localPath;
  final int totalBytes;
  final int downloadedBytes;
  final DownloadStatus status;

  const DownloadItem({
    required this.contentId,
    required this.title,
    required this.poster,
    required this.quality,
    required this.localPath,
    required this.totalBytes,
    required this.downloadedBytes,
    required this.status,
  });

  double get progress => totalBytes > 0 ? downloadedBytes / totalBytes : 0;

  DownloadItem copyWith({
    int? totalBytes,
    int? downloadedBytes,
    DownloadStatus? status,
  }) {
    return DownloadItem(
      contentId: contentId,
      title: title,
      poster: poster,
      quality: quality,
      localPath: localPath,
      totalBytes: totalBytes ?? this.totalBytes,
      downloadedBytes: downloadedBytes ?? this.downloadedBytes,
      status: status ?? this.status,
    );
  }

  Map<String, dynamic> toJson() => {
        'contentId': contentId,
        'title': title,
        'poster': poster,
        'quality': quality,
        'localPath': localPath,
        'totalBytes': totalBytes,
        'downloadedBytes': downloadedBytes,
        'status': status.name,
      };

  factory DownloadItem.fromJson(Map<String, dynamic> json) {
    return DownloadItem(
      contentId: json['contentId'] as String,
      title: json['title'] as String? ?? '',
      poster: json['poster'] as String? ?? '',
      quality: json['quality'] as String? ?? 'sd',
      localPath: json['localPath'] as String,
      totalBytes: (json['totalBytes'] as num?)?.toInt() ?? 0,
      downloadedBytes: (json['downloadedBytes'] as num?)?.toInt() ?? 0,
      status: DownloadStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => DownloadStatus.failed,
      ),
    );
  }
}
