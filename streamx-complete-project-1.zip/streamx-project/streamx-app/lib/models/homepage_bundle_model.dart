import 'content_model.dart';

class HomeRow {
  final String title;
  final String category;
  final List<ContentModel> items;

  const HomeRow({required this.title, required this.category, required this.items});

  factory HomeRow.fromJson(Map<String, dynamic> json) {
    return HomeRow(
      title: json['title'] as String? ?? '',
      category: json['category'] as String? ?? '',
      items: (json['items'] as List? ?? [])
          .map((e) => ContentModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

class HomepageBundle {
  final List<ContentModel> hero;
  final List<HomeRow> rows;

  const HomepageBundle({required this.hero, required this.rows});

  factory HomepageBundle.fromJson(Map<String, dynamic> json) {
    return HomepageBundle(
      hero: (json['hero'] as List? ?? [])
          .map((e) => ContentModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      rows: (json['rows'] as List? ?? [])
          .map((e) => HomeRow.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}
